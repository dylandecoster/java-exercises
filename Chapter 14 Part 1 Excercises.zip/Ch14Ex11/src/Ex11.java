/*
Dylan DeCoster
Chapter 14 Excercise 1
Description: Draw a smile face
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.geometry.Insets;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Arc;

public class Ex11 extends Application{
    @Override
    public void start(Stage primaryStage){
        Pane pane = new Pane();
        pane.setPadding(new Insets(15,15,15,15));
        
        //Makes a circle with a radius of 100
        Circle head = new Circle();
        head.centerXProperty().bind(pane.widthProperty().divide(2));
        head.centerYProperty().bind(pane.heightProperty().divide(2));
        head.setRadius(100);
        head.setStyle("-fx-stroke: black; -fx-fill: white;");
        
        //Makes an eye
        Ellipse eye1 = new Ellipse(25, 20);
        eye1.centerXProperty().bind(pane.widthProperty().divide(2).add(45));
        eye1.centerYProperty().bind(pane.heightProperty().divide(3));
        eye1.setStyle("-fx-stroke: black; -fx-fill: white;");
        
        //Makes another eye
        Ellipse eye2 = new Ellipse(25, 20);
        eye2.centerXProperty().bind(pane.widthProperty().divide(2).subtract(45));
        eye2.centerYProperty().bind(pane.heightProperty().divide(3));
        eye2.setStyle("-fx-stroke: black; -fx-fill: white;");
        
        //Makes the first pupil
        Circle pupil1 = new Circle();
        pupil1.centerXProperty().bind(pane.widthProperty().divide(2).subtract(45));
        pupil1.centerYProperty().bind(pane.heightProperty().divide(3));
        pupil1.setRadius(10);
        
        //Makes the second pupil
        Circle pupil2 = new Circle();
        pupil2.centerXProperty().bind(pane.widthProperty().divide(2).add(45));
        pupil2.centerYProperty().bind(pane.heightProperty().divide(3));
        pupil2.setRadius(10);
        
        //Makes a really crappy arc smile
        Arc smile = new Arc(130, 180, 50, 20, 180, 180);
        smile.centerXProperty().bind(pane.widthProperty().divide(2));
        smile.centerYProperty().bind(pane.heightProperty().divide(2).add(45));
        
        //Makes a nose with the following coords
        Polygon nose = new Polygon();
        nose.getPoints().addAll(new Double[]{
            150.0, 125.0,
            125.0, 175.0,
            175.0, 175.0
        });
        nose.setStyle("-fx-stroke: black; -fx-fill: white;");
        
        //Shows everything on the pane
        pane.getChildren().add(head);
        pane.getChildren().add(eye1);
        pane.getChildren().add(eye2);
        pane.getChildren().add(smile);
        pane.getChildren().add(pupil1);
        pane.getChildren().add(pupil2);
        pane.getChildren().add(nose);
        
        
        //Makes a new scene with the title Excercise 7
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Excercise 7");
        primaryStage.setScene(scene);
        //Shows the scene
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }    
}
