/*
Dylan DeCoster
Chapter 14 Excercise 1
Description: Display a 10x10 matrix of random 0's and 1's
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.layout.GridPane;
import javafx.scene.control.TextField;

public class Ex7 extends Application{
    @Override
    public void start(Stage primaryStage){
        //Makes a new grid pane with a padding of 10 on each side
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(10, 10, 10, 10));

        //Makes a new random int
        int num = (int)(Math.random() * 2);
        //Makes a new textfield set to 25x25
        TextField toNum = new TextField("1");
        toNum.setMaxHeight(25);
        toNum.setMaxWidth(25);
        
        //Makes the 10x10 area
        for(int i = 0; i < 10; i++){
            for(int j = 0; j < 10; j++){
                //Puts a number in each grid square
                pane.add(toNum, i, j);
                //Gets a new random number
                num = (int)(Math.random() * 2);
                //Makes a new text field and sets it to the num
                toNum = new TextField(String.valueOf(num));
                //Sets the height of each square to 25x25
                toNum.setMaxHeight(25);
                toNum.setMaxWidth(25);
            }
        }
        
        //Makes a new scene with the title Excercise 7
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Excercise 7");
        primaryStage.setScene(scene);
        //Shows the scene
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }   
}
