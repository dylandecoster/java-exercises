/*
Dylan DeCoster
Chapter 14 Excercise 1
Description: Write a program that displays four images in a grid pane
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.GridPane;

public class Ex1 extends Application{
    @Override
    public void start(Stage primaryStage) {
        //Makes a new GridPane
        GridPane pane = new GridPane();
        //Adds some padding to it
        pane.setPadding(new Insets(10, 10, 10, 10));
        
        //Makes a new image with a width of 200, a height of 100 in grid position 0, 0
        Image us = new Image("image/USFlag.png", 200, 100, false, false);
        pane.add(new ImageView(us), 0, 0);
        //Makes a new image with a width of 200, a height of 100 in grid position 0, 1
        Image uk = new Image("image/UKFlag.png", 200, 100, false, false);
        pane.add(new ImageView(uk), 0, 1);
        //Makes a new image with a width of 200, a height of 100 in grid position 1, 0
        Image canada = new Image("image/CanadaFlag.png", 200, 100, false, false);
        pane.add(new ImageView(canada), 1, 0);
        //Makes a new image with a width of 200, a height of 100 in grid position 1, 1
        Image china = new Image("image/ChinaFlag.png", 200, 100, false, false);
        pane.add(new ImageView(china), 1, 1);        
        
        //Makes a new scene with the grid pane
        Scene scene = new Scene(pane);
        //Sets the title of the scene
        primaryStage.setTitle("Excercise 14.1");
        primaryStage.setScene(scene);
        //Shows the scene
        primaryStage.show();
    }    
    
    public static void main(String[] args){
        //Launches the scene
        Application.launch(args);
    }
}
