/*
Dylan DeCoster
Chapter 10 Excercise 3
Description: Tests a bunch of stuff on an integer
 */

public class Ex3 {
    public static void main(String[] args) {
        //Sets myInt to 10
        MyInteger myInt = new MyInteger(10);
        //Tests everything according to the value of myInt
        System.out.println(MyInteger.isEven(myInt) + " " + MyInteger.isOdd(myInt) + " " + MyInteger.isPrime(myInt));
        //Tests everything according to the value of whatever I input
        System.out.println(MyInteger.isEven(5) + " " + MyInteger.isOdd(5) + " " + MyInteger.isPrime(5));
        
        //Makes a new char array
        char[] arr = new char[]{'1', '2', '3', '4', '5'};
        //Makes a new string
        String str = "512";
        //Converts the char arr to an int
        System.out.println(MyInteger.parseInt(arr));
        //Converts the string to an int
        System.out.println(MyInteger.parseInt(str));
    }
}
