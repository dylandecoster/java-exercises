public class MyInteger {
    int value;
    
    public MyInteger(int val){
        value = val;
    }
    //Simple getter for value
    public int getValue() {
        return value;
    }
    
    //Checks if the value is an even number
    public boolean isEven(){
        if(getValue() % 2 == 0)
            return true;
        
        return false;
    }
    //Checks if the value is an odd number
    public boolean isOdd(){
        if(getValue() % 2 != 0)
            return true;
        
        return false;
    }
    //Checks if the value is a prime number
    public boolean isPrime(){
        if(getValue() <= 1)
            return false;
        
        for(int i = 2; 1 < getValue(); i++){
            if(getValue() % i == 0)
                return false;
        }
        
        return true;
    }
        
    //Checks if x is an even number
    public static boolean isEven(int x){
        if(x % 2 == 0)
            return true;
        
        return false;
    }
    //Checks if y is an odd number
    public static boolean isOdd(int y){
        if(y % 2 != 0)
            return true;
        
        return false;
    }   
    //Checks if z is a prime number
    public static boolean isPrime(int z){
        if(z <= 1)
            return false;
        
        for(int i = 2; 1 < z; i++){
            if(z % i == 0)
                return false;
        }
        
        return true;
    }
        
    //Checks if myInt is an even number
    public static boolean isEven(MyInteger myInt){
        if(myInt.value % 2 == 0){
            return true;
        }
        
        return false;
    }
    //Checks if myInt is an odd number
    public static boolean isOdd(MyInteger myInt){
        if(myInt.value % 2 != 0){
            return true;
        }
        
        return false;
    }   
    //Checks if myInt is a prime number
    public static boolean isPrime(MyInteger myInt){
        if(myInt.value <= 1)
            return false;
        
        for(int i = 2; 1 < myInt.value; i++){
            if(myInt.value % i == 0)
                return false;
        }
        
        return true;
    }
    
    //Checks if x is equal to value
    public boolean equals(int x){
        if(x == value)
            return true;
        
        return false;
    }
    //Checks if the integer equals myInt
    public boolean equals(MyInteger myInt){
        if(myInt.equals(this))
            return true;
        
        return false;
    }
    
    //Converts the char array to a string then to an int
    public static int parseInt(char[] a){
        return Integer.parseInt(new String(a));
    }
    //Converts the string into an int
    public static int parseInt(String a){
        return Integer.parseInt(a);
    }
}