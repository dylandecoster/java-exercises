/*
Dylan DeCoster
Chapter 10 Excercise 14
Description: 
 */

public class Ex14 {
    public static void main(String[] args) {
        //Makes some new dates
        MyDate date1 = new MyDate();
        MyDate date2 = new MyDate(34355555133101L);
        
        //Prints out the dates
        System.out.println(date1.getMonth() + "/" + date1.getDay() + "/" + date1.getYear());
        System.out.println(date2.getMonth() + "/" + date2.getDay() + "/" + date2.getYear());
    }
}
