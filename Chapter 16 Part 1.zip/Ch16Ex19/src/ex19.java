/*
Dylan DeCoster
Chapter 15 Exercise 28
Create a moving fan
 */

import javafx.animation.*;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ex19 extends Application {
    Timeline[] anims = new Timeline[3]; // Stores all the animations
    
    @Override
    public void start(Stage primaryStage) {
        FanPane[] fan = new FanPane[3]; // Array of all the fans
        HBox fans = new HBox(10); // HBox of the fans
        for(int i = 0; i < 3; i++) {
            fans.getChildren().addAll(createFan(fan, i)); // Adds all the fans to the scene
        }
        
        // Creates the start and stop all buttons
        HBox controlAll = new HBox(10);
        Button startAll = new Button("Start All");
        Button stopAll = new Button("Stop All");
        controlAll.getChildren().addAll(startAll, stopAll);
        controlAll.setAlignment(Pos.CENTER);
        
        // Positions everything
        BorderPane pane = new BorderPane();
        pane.setTop(fans);
        pane.setBottom(controlAll);
        
        stopAll.setOnAction(e -> {
            anims[0].pause();
            anims[1].pause();
            anims[2].pause();
        });
        
        startAll.setOnAction(e -> {
            anims[0].play();
            anims[1].play();
            anims[2].play();
        });
        
        Scene scene = new Scene(pane, 600, 250);
        
        primaryStage.setTitle("Exercise 15.28");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    Pane createFan(FanPane[] fan, int fanNum) {
        // Creates all the buttons and positions them at the bottom of the screen
        HBox hb = new HBox(5);
        Button pause = new Button("Pause");
        Button resume = new Button("Resume");
        Button reverse = new Button("Reverse");
        hb.setAlignment(Pos.CENTER);
        hb.getChildren().addAll(pause, resume, reverse);
        
        // Creates a new pane for the fan
        BorderPane pane = new BorderPane();
        pane.setTop(hb);
        
        // Creates the fan
        fan[fanNum] = new FanPane();
        pane.setCenter(fan[fanNum]);
        
        // Creates the animation
        Timeline animation = new Timeline(
            new KeyFrame(Duration.millis(100), e -> fan[fanNum].move()));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
        
        anims[fanNum] = animation; // Sets the array to the correct fans animation
        
        // Sets the buttons to there action
        pause.setOnAction(e -> animation.pause());
        resume.setOnAction(e -> animation.play());
        reverse.setOnAction(e -> fan[fanNum].reverse());
        
        return pane;
    }


    public static void main(String[] args) {
        launch(args);
    }
    
}
