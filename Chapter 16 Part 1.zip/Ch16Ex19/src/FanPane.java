import javafx.scene.layout.Pane;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;

public class FanPane extends Pane{
    private double w = 200, h = 200, radius = Math.min(w, h) * 0.45;
    private Arc arc[] = new Arc[4];
    private double startAngle = 30;
    private Circle circle = new Circle(w/2, h/2, radius);
    
    // Creates the fan blades
    public FanPane() {
        circle.setStroke(javafx.scene.paint.Color.BLACK);
        circle.setFill(javafx.scene.paint.Color.WHITE);
        getChildren().add(circle);
        
        for(int i = 0; i < 4; i++) {
            arc[i] = new Arc(w/2, h/2, radius * 0.9, radius * 0.9, startAngle + i * 90, 35);
            arc[i].setFill(javafx.scene.paint.Color.RED);
            arc[i].setType(ArcType.ROUND);
            getChildren().add(arc[i]);
        }
    }
    
    public void setValues() {
        radius = Math.min(w, h) * 0.45;
        circle.setRadius(radius);
        circle.setCenterX(w/2);
        circle.setCenterY(h/2);
        
        for(int i = 0; i < 4; i++) {
            arc[i].setRadiusX(radius * 0.9);
            arc[i].setRadiusY(radius * 0.9);
            arc[i].setCenterX(w/2);
            arc[i].setCenterY(h/2);
            arc[i].setStartAngle(startAngle + i * 90);
        }
    }
    
    private double increment = 5;
    
    // Controls the fans movement
    public void move() {
        setStartAngle(startAngle + increment);
    }
    public void reverse() {
        increment = -increment;
    }
    public void setStartAngle(double angle) {
        this.startAngle = angle;
        setValues();
    }
    
    public void setW(double w) {
        this.w = w;
        setValues();
    }
    public void setH(double h) {
        this.h = h;
        setValues();
    }
}
