/*
Dylan DeCoster
Chapter 16 Exercise 3
Create a traffic light program
 */

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.scene.paint.Color;

public class ex3 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        BorderPane pane = new BorderPane();
        HBox btnPane = new HBox(25);
        
        // Creates the traffic light rectangle
        Rectangle rectangle = new Rectangle(100, 50, 50, 100);
        rectangle.setFill(Color.WHITE);
        rectangle.setStroke(Color.BLACK);
        pane.getChildren().add(rectangle);
        
        // Creates all the lights within the traffic light
        Circle circle1 = new Circle(125, 75, 10, Color.WHITE);
        Circle circle2 = new Circle(125, 100, 10, Color.WHITE);
        Circle circle3 = new Circle(125, 125, 10, Color.WHITE);
        circle1.setStroke(Color.BLACK);
        circle2.setStroke(Color.BLACK);
        circle3.setStroke(Color.BLACK);
        pane.getChildren().addAll(circle1, circle2, circle3);
        
        // Creates all the radio buttons
        RadioButton red = new RadioButton("Red");
        RadioButton yellow = new RadioButton("Yellow");
        RadioButton green = new RadioButton("Green");
        btnPane.getChildren().addAll(red, yellow, green);
        
        // Sets the radio buttons into the same group
        ToggleGroup group = new ToggleGroup();
        red.setToggleGroup(group);
        yellow.setToggleGroup(group);
        green.setToggleGroup(group);

        btnPane.setAlignment(Pos.CENTER);
        pane.setBottom(btnPane);

        // Sets up all the radiobuttons to change colors
        red.setOnAction(e -> {
            if(red.isSelected()) {
                circle1.setFill(Color.RED);
                circle2.setFill(Color.WHITE);
                circle3.setFill(Color.WHITE);
            }
        });
        yellow.setOnAction(e -> {
            if(yellow.isSelected()) {
                circle1.setFill(Color.WHITE);
                circle2.setFill(Color.YELLOW);
                circle3.setFill(Color.WHITE);
            }
        });
        green.setOnAction(e -> {
            if(green.isSelected()) {
                circle1.setFill(Color.WHITE);
                circle2.setFill(Color.WHITE);
                circle3.setFill(Color.GREEN);
            }
        });
        
        Scene scene = new Scene(pane, 250, 200);

        primaryStage.setTitle("Exercise 16.3");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
