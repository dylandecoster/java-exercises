/*
Dylan DeCoster
Chapter 16 Exercise 10
Display a text file in a text area.
 */

import java.io.*;
import java.util.Scanner;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

public class ex10 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        BorderPane pane = new BorderPane();
        HBox bottom = new HBox(5);
        
        // Creates and positions the text area
        TextArea file = new TextArea("");
        file.setPrefSize(300, 200);
        file.setWrapText(true);
        file.setEditable(false);
        ScrollPane scrollPane = new ScrollPane(file);
        pane.setTop(scrollPane);
        
        // Creates the bottom ui
        Label lbl = new Label("Filename: ");
        TextField fileName = new TextField();
        fileName.setMinWidth(190);
        Button view = new Button("View");
        
        view.setOnAction(e -> {
            try {
                File fl = new File(fileName.getText()); // Gets the file
                Scanner scanner = new Scanner(fl); // Creates a scanner to read from the file
                while(scanner.hasNextLine()) { // Checks for the next line
                    file.setText(file.getText() + "\n" + scanner.nextLine()); // Sets the text area to the file
                }
                
            } catch (Exception ex) {
                file.setText("Error: File was not found."); // If the file wasn't found
            }
        });
        
        // Adds the bottom stuff to the bottom of the pane
        bottom.getChildren().addAll(lbl, fileName, view);
        pane.setBottom(bottom);

        Scene scene = new Scene(pane, 300, 250);
        
        primaryStage.setTitle("Chapter 16.10");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
