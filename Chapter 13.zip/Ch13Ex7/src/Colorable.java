public interface Colorable {
    // Creates the howToColor method
    public abstract String howToColor();
}
