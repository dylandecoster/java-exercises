/*
Dylan DeCoster
Chapter 13 Exercise 7
Describe how to color a square using a lot of classes
 */
public class ex7 {
    public static void main(String[] args) {
        // Creates the objects
        GeometricObject[] obj = new GeometricObject[5];
        for(int i = 0; i < 5; i++) {
            // Makes all the objects squares and assigns them a side length
            obj[i] = new Square(5 + i);
            // Gets the area  and how to color info of the current square
            System.out.println("The area of square " + (1 + i) + ": " + obj[i].getArea());
            System.out.println(color((Square) obj[i]));
        }
    }
    
    public static String color(Square square) {
        return square.howToColor();
    }
}
