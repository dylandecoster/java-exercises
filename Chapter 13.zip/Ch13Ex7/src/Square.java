class Square extends GeometricObject implements Colorable{
    double sideLength;
    
    //Gets the squares side lengths
    public Square(double sideLength) {
        this.sideLength = sideLength;
    }
    
    public double getSide() {
        return sideLength;
    }
    
    // Writes the how to color thing
    @Override
    public String howToColor() {
        return "Square: Color all four sides.";
    }
    
    // Gets the area of the square
    @Override
    public double getArea() {
        return sideLength * sideLength;
    }

    // Gets the perimeter of the square
    @Override
    public double getPerimeter() {
        return sideLength * 4;
    }
}
