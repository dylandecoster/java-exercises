/*
Dylan DeCoster
Chapter 13 Exercise 10
Rewrite the equals method
 */
public class ex10 {
    public static void main(String[] args) {
        // Creates and tests the rectangles
        Rectangle obj = new Rectangle();
        Rectangle obj2 = new Rectangle(12, 55);
        System.out.println(obj.equals(obj2));
        System.out.println(obj.compareTo(obj2));
    }
}
