public class Rectangle extends GeometricObject implements Comparable {
    private double width, height;
    
    // Default rectangle
    public Rectangle() {
        this(1, 1);
    }
    
    // Sets the rectangle dimensions
    public Rectangle(double width, double height) {
        this.width = width;
        this.height = height;
    }

    // Bunch of getters and setters
    public double getWidth() {
        return width;
    }
    public void setWidth(double width) {
        this.width = width;
    }
    public double getHeight() {
        return height;
    }
    public void setHeight(double height) {
        this.height = height;
    }
    
    // Does the math
    public double getArea() {
        return width * height;
    }
    public double getPerimeter() {
        return 2 * (width + height);
    }
    
    // Compares the two rectangles
    public int compareTo(Object o) {
        if(this.getArea() > ((Rectangle)o).getArea()) {
            return 1;
        }
        else if(this.getArea() < ((Rectangle)o).getArea()) {
            return -1;
        }
        else {
            return 0;
        }
    }
    
    // Checks if the rectangles are equal
    public boolean equals(Object o) {
        return (this.getArea() == ((Rectangle)o).getArea());
    }
}
