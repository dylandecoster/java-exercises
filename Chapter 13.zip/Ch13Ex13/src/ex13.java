/*
Dylan DeCoster
Chapter 13 Exercise 13
Deep Clone the course class
 */
public class ex13 {
    public static void main(String[] args) throws CloneNotSupportedException{
        Course course = new Course("Algebra"); // Creates a course
        Course course2 = (Course)course.clone(); // Clones the course
    }
}
