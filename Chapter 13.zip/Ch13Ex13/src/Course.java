public class Course implements Cloneable {
    private String courseName;
    private String[] students = new String[10];
    private int numOfStudents;
    
    public Course(String courseName) {
        this.courseName = courseName;
    }
    
    public void addStudent(String student) {
        students[numOfStudents] = student;
        numOfStudents++;
    }
    
    // All the getters
    public String getCourseName() {
        return courseName;
    }
    public String[] getStudents() {
        return students;
    }
    public int getNumOfStudents() {
        return numOfStudents;
    }
    
    // Overrides the clone method and clones this course
    @Override
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}
