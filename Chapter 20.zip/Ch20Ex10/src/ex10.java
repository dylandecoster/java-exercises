/*
Dylan DeCoster
Chapter 20 Exercise 10
Find the difference, union, and intersection of two priority queues
 */

import java.util.*;

public class ex10 {
    public static void main(String[] args) {
        // Creates and fills both queues
        PriorityQueue<String> q1 = new PriorityQueue<>(Arrays.asList("George", "Jim", "John", "Blake", "Kevin", "Michael"));
        PriorityQueue<String> q2 = new PriorityQueue<>(Arrays.asList("George", "Katie", "Kevin", "Michelle", "Ryan"));
       
        // Prints everything out
        System.out.println("Union: " + union(q1, q2));
        System.out.println("Difference: " + difference(q1, q2));
        System.out.println("Intersection: " + intersection());
    }
    
    
    // Merges both queues
    public static PriorityQueue union(PriorityQueue q1, PriorityQueue q2) {
        q1.addAll(q2);
        return q1;
    }
    
    // Returns only the unique items in the queues
    public static PriorityQueue difference(PriorityQueue q1, PriorityQueue q2) {
        q1.removeAll(q2);
        return q1;
    }
    
    // Returns only the same items in both queues
    public static PriorityQueue intersection() {
        PriorityQueue<String> q1 = new PriorityQueue<>(Arrays.asList("George", "Jim", "John", "Blake", "Kevin", "Michael"));
        PriorityQueue<String> q2 = new PriorityQueue<>(Arrays.asList("George", "Katie", "Kevin", "Michelle", "Ryan"));
        
        q1.retainAll(q2);
        return q1;
    }
}
