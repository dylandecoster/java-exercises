/*
Dylan DeCoster
Chapter 20 Exercise 13
24 point card game
 */

import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class ex13 extends Application {
    int[] cardValues = new int[4];
    
    @Override
    public void start(Stage primaryStage) {
        // Creates the panes
        GridPane cardHolder = new GridPane();
        BorderPane root = new BorderPane();
        
        // Shuffles the first set of cards
        shuffleCards(cardHolder, root);

        // Result text area
        TextArea result = new TextArea();
        result.setEditable(false);
        result.setWrapText(true);
        result.setMaxSize(325, 35);
        
        // Shuffle button
        Button shuffle = new Button("Shuffle");
        shuffle.setMaxSize(60, 15);
        shuffle.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                shuffleCards(cardHolder, root);
            }
        });

        // Stores the shuffle button and the result
        HBox screenTop = new HBox(10);
        screenTop.setPadding(new Insets(25, 0, 0, 95));
        screenTop.getChildren().addAll(result, shuffle);
        
        // Expression label
        Label expressionLbl = new Label();
        expressionLbl.setText("Enter an expression: ");
        
        // User inputed expression area
        TextArea expression = new TextArea();
        expression.setMaxSize(200, 15);
        
        // Verify button
        Button verify = new Button("Verify");
        verify.setPrefSize(60, 15);
        verify.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    verifyAnswer(expression, result);
                } catch (ScriptException ex) {
                    Logger.getLogger(ex13.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        
        // Stores the verify button, and the expression stuff
        HBox screenBottom = new HBox(10);
        screenBottom.setPadding(new Insets(0, 0, 20, 50));
        screenBottom.getChildren().addAll(expressionLbl, expression, verify);
        
        // Positions everything
        root.setTop(screenTop);
        root.setCenter(cardHolder);
        root.setBottom(screenBottom);
        
        Scene scene = new Scene(root, 500, 250);
        primaryStage.setTitle("Exercise 20.13");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    void shuffleCards(GridPane cardHolder, BorderPane root) {
        Random rand = new Random(); // Creates a new random
        // Adds for random cards into the gridpane
        for(int i = 0; i < 4; i++) {
            int selectRandom = rand.nextInt((52 - 1) + 1) + 1; // Gets a random number
            cardHolder.add(new ImageView("card/" + selectRandom + ".png"), i, 0); // Gets the image from the file and adds it into the gridpane
            cardValues[i] = selectRandom % 13;
            if(cardValues[i] == 0)
                cardValues[i] = 13;
        }
        cardHolder.setHgap(8); // Spaces out the cards
        cardHolder.setAlignment(Pos.CENTER); // Positions the cards in the center of the screen
    }
    
    void verifyAnswer(TextArea expression, TextArea result) throws ScriptException {
        // Allows me to use JavaScript's evaluate function
        ScriptEngineManager manager = new ScriptEngineManager();
        ScriptEngine engine = manager.getEngineByName("js");
        
        String resultStr = engine.eval(expression.getText()).toString(); // Does all the math
        
        boolean isMatching = true; // To check if the numbers match with the cards
        String numbersFromString = expression.getText().replaceAll("\\D+", " "); // Removes everything except numbers from the string
        
        // Removes the extra space if the string started with a (
        if(numbersFromString.startsWith(" "))
            numbersFromString = numbersFromString.substring(1, numbersFromString.length());
        String[] splitResult = numbersFromString.split(" "); // Splits all the numbers into an array
        // Checks that there is at least 4 numbers
        if(splitResult.length >= 4) {
            // Checks if the numbers match
            for(int i = 0; i < 4; i++) {
                if(!splitResult[i].contains(String.valueOf(cardValues[i]))) {
                    isMatching = false;
                    break;
                }
            }
        } else isMatching = false;
        
        if(!isMatching)
            result.setText("The numbers in the expression don't match the numbers in the set");
        
        if(Integer.parseInt(resultStr) != 24 && isMatching)
            result.setText("Incorrect Result");
        else if(Integer.parseInt(resultStr) == 24 && isMatching)
            result.setText("Correct");
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
