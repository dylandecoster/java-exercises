/*
Dylan DeCoster
Chapter 20 Exercise 7
Create a hangman game
 */

import java.util.*;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.*;
import javafx.animation.*;
import javafx.scene.Group;
import javafx.scene.transform.Rotate;
import javafx.util.Duration;

public class Hangman extends Application {
    Pane root = new Pane();
    private String[] words = new String[]{"recieve", "blessings", "fathom"};
    List<Character> wordList = new ArrayList<>();
    
    private String temp = "", missingLetters = "";
    private boolean missingAdded = false, gameDone = false;
    private int index = 0, currentWord = 0;
    
    @Override
    public void start(Stage primaryStage) {
        Label guess = new Label("Guess a word: ");
        Label word = new Label();
        
        // Creates an HBox that stores the word and "Guess a word: " label
        HBox guessBox = new HBox();
        guessBox.setLayoutX(225);
        guessBox.setLayoutY(375);
        guessBox.getChildren().addAll(guess, word);
        root.getChildren().add(guessBox);
        
        Label miss = new Label("Missed letters: ");
        Label missing = new Label();
        
        // Creates an HBox that stores the missing letters and "Missed letters: " label
        HBox missBox = new HBox();
        missBox.setLayoutX(225);
        missBox.setLayoutY(400);
        missBox.getChildren().addAll(miss, missing);
        
        // Creates the finished label
        Label finished = new Label("To continue the game, press ENTER");
        finished.setLayoutX(225);
        finished.setLayoutY(400);
        
        resetGame(finished, word, guessBox);
        
        Scene scene = new Scene(root, 600, 500);
        scene.addEventHandler(KeyEvent.KEY_PRESSED, (key) -> {
            char[] keyPressedArr = key.getCode().getName().toCharArray(); // Gets the key pressed and converts it to an array of characters
            
            // Resets the game
            if(key.getCode() == KeyCode.ENTER && gameDone == true)
                resetGame(finished, word, guessBox);
            
            // If the key pressed wasn't a letter it returns
            if(keyPressedArr.length > 1) {
                return;
            } else if (gameDone != true){ // Otherwise it checks for occurences of that letter in the word
                char keyPressed = Character.toLowerCase(keyPressedArr[0]); // Converts the letter to lowercase
                // Replaces the '*' with the correct letter if it finds it in the word
                if(wordList.contains(keyPressed)) {
                    for(int i = 0; i < wordList.size(); i++) {
                        if(wordList.get(i) == keyPressed) {
                            String newTemp = temp.substring(0,i) + keyPressed + temp.substring(i+1);
                            temp = newTemp;
                        }
                    }
                    word.setText(temp);
                    
                    // Finishes the game if the word is solved
                    if(!temp.contains("*")) {
                        root.getChildren().remove(missBox);
                        root.getChildren().add(finished);
                        gameDone = true;
                    }

                } else {
                    // Checks to see if the Missed Letters labels have already appeared
                    if(missingAdded == false) {
                        root.getChildren().add(missBox);
                        missingAdded = true;
                    }
 
                    // If the letter is missing it adds it to the label
                    if(!missingLetters.contains(String.valueOf(keyPressed)))
                        missingLetters += keyPressed;
                    else return;
                    missing.setText(missingLetters);
                    
                    // Adds another part to the hangman
                    index++;
                    createHangman(index);
                    
                    // If you fail 7 times it shows the finished label
                    if(index == 7) {
                        root.getChildren().remove(missBox);
                        root.getChildren().add(finished);
                        gameDone = true;
                    }
                }
            }
        });
        
        primaryStage.setTitle("Hangman");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    void createTree() {
        // Creates the line parts of the tree
        Polyline treeMain = new Polyline();
        treeMain.getPoints().addAll(new Double[]{
            300.0, 85.0,
            300.0, 50.0,
            115.0, 50.0,
            115.0, 400.0
        });
        root.getChildren().add(treeMain);
        
        // Creates the bottom arc on the tree
        Arc treeBase = new Arc(115, 435, 75, 35, 0, 180);
        treeBase.setFill(Color.TRANSPARENT);
        treeBase.setStroke(Color.BLACK);
        root.getChildren().add(treeBase);
    }
    
    void createHangman(int partIndex) {
        Circle head = new Circle(300, 115, 30);
        head.setFill(Color.TRANSPARENT);
        head.setStroke(Color.BLACK);
        
        Line arm1 = new Line(275, 130, 175, 215);
        Line arm2 = new Line(325, 130, 415, 215);
        Line body = new Line(300, 145, 300, 275);
        Line leg1 = new Line(300, 275, 215, 345);
        Line leg2 = new Line(300, 275, 375, 345);
        
        Group human = new Group();
        human.getChildren().addAll(arm1, arm2, body, leg1, leg2, head);
        
        switch(partIndex) {
            case 1: root.getChildren().add(head); break;
            case 2: root.getChildren().add(arm1); break;
            case 3: root.getChildren().add(arm2); break;
            case 4: root.getChildren().add(body); break;
            case 5: root.getChildren().add(leg1); break;
            case 6: root.getChildren().add(leg2); break;
            case 7: hangAnim(human); 
        }
    }
    
    void hangAnim(Group human) {
        root.getChildren().clear();
        createTree();
        
        // Creates the pivot point that the human goes around
        Line line = new Line(300, 85, 300, 85);
        Rotate rotation = new Rotate();
        rotation.pivotXProperty().bind(line.startXProperty());
        rotation.pivotYProperty().bind(line.startYProperty());
        human.getTransforms().add(rotation);

        // Creates the animation
        Timeline timeline = new Timeline(
            new KeyFrame(Duration.ZERO, new KeyValue(rotation.angleProperty(), 0)),
            new KeyFrame(Duration.seconds(1), new KeyValue(rotation.angleProperty(), 8)),
            new KeyFrame(Duration.seconds(2), new KeyValue(rotation.angleProperty(), 0)),
            new KeyFrame(Duration.seconds(3), new KeyValue(rotation.angleProperty(), -8)));

        timeline.setAutoReverse(true);
        timeline.setCycleCount(Timeline.INDEFINITE);
        timeline.play();
        root.getChildren().add(human);
    }
    
    void resetGame(Label finished, Label word, HBox guessBox) {
        root.getChildren().clear();
        root.getChildren().add(guessBox);
        createTree();
        
        gameDone = false;
        missingAdded = false;

        index = 0;
        wordList = new ArrayList<>();
        
        // Stores an array of the words letters
        for(int i = 0; i < words[currentWord].length(); i++) {
            wordList.add(i, words[currentWord].charAt(i));
        }

        temp = "";
        missingLetters = "";
        
        // Sets the text of the word all to asteriks
        for(int i = 0; i < wordList.size(); i++)
            temp += "*";
        word.setText(temp);
        
        currentWord++;
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}
