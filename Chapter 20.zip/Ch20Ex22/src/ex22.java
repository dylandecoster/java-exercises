/*
Dylan DeCoster
Chapter 20 Exercise 22
Recreate the Tower of Hanoi game using a stack instead of recursion
 */

import java.util.*;

public class ex22 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of disks: ");
        int n = input.nextInt();
        
        System.out.println("The moves are: ");
        moveDisks(n, 'A', 'B', 'C');
    }
    
    public static void moveDisks(int n, char a, char b, char c) {
        Stack<Integer> t1 = new Stack<>();
        Stack<Integer> t2 = new Stack<>();
        Stack<Integer> t3 = new Stack<>();
        
        for(int i = n; i > 0; i--)
            t1.push(i);
        
        if(n == 1)
            System.out.println("Move disk " + n + " from " + a + " to " + b);
        else {
            for(int i = 0; i < ((Math.pow(2, n) - 1) / 3); i++) { // AMOUNT OF TURNS NEEDED
                if(n % 2 != 1)  { // IF THE NUMBER IS EVEN
                    // A TO B
                    if (!t1.empty() && !t2.empty()){
                        if(t1.peek() < t2.peek()) {
                            t2.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + b);
                            t1.pop();
                        } else {
                            t1.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + a);
                            t1.pop();
                        }
                    } else if(!t1.empty() || !t2.empty()) {
                        if(t2.empty()) {
                            t2.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + b);
                            t1.pop();
                        } else {
                            t1.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + a);
                            t1.pop();
                        }
                    }
                    // A TO C
                    if (!t3.empty() && !t1.empty()) {
                        if(t1.peek() < t3.peek()) {
                            t3.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + c);
                            t1.pop();
                        } else {
                            t1.push(t3.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + c + " to " + a);
                            t3.pop();
                        }
                    }else if(!t3.empty() || !t1.empty()) {
                        if(t3.empty()) {
                            t3.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + c);
                            t1.pop();
                        } else {
                            t1.push(t3.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + c + " to " + a);
                            t3.pop();
                        }
                    }
                    // B TO C
                    if (!t3.empty() && !t2.empty()) {
                        if(t2.peek() < t3.peek()) {
                            t3.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + c);
                            t2.pop();
                        } else {
                            t2.push(t3.peek());
                            System.out.println("Move disk " + t3.peek() + " from " + c + " to " + b);
                            t3.pop();
                        }
                    }else if(!t3.empty() || !t2.empty()) {
                        if(t3.empty()) {
                            t3.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + c);
                            t2.pop();
                        } else {
                            t2.push(t3.peek());
                            System.out.println("Move disk " + t3.peek() + " from " + c + " to " + b);
                            t3.pop();
                        }
                    } 
                } else if(n % 2 == 1) { // IF THE NUMBER IS ODD
                    // A TO C
                    if (!t3.empty() && !t1.empty()) {
                        if(t1.peek() < t3.peek()) {
                            t3.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + c);
                            t1.pop();
                        } else {
                            t1.push(t3.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + c + " to " + a);
                            t3.pop();
                        }
                    }else if(!t3.empty() || !t1.empty()) {
                        if(t3.empty()) {
                            t3.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + c);
                            t1.pop();
                        } else {
                            t1.push(t3.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + c + " to " + a);
                            t3.pop();
                        }
                    }
                    // A TO B
                    if (!t1.empty() && !t2.empty()){
                        if(t1.peek() < t2.peek()) {
                            t2.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + b);
                            t1.pop();
                        } else {
                            t1.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + a);
                            t1.pop();
                        }
                    } else if(!t1.empty() || !t2.empty()) {
                        if(t2.empty()) {
                            t2.push(t1.peek());
                            System.out.println("Move disk " + t1.peek() + " from " + a + " to " + b);
                            t1.pop();
                        } else {
                            t1.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + a);
                            t1.pop();
                        }
                    }
                    // B TO C
                    if (!t3.empty() && !t2.empty()) {
                        if(t2.peek() < t3.peek()) {
                            t3.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + c);
                            t2.pop();
                        } else {
                            t2.push(t3.peek());
                            System.out.println("Move disk " + t3.peek() + " from " + c + " to " + b);
                            t3.pop();
                        }
                    }else if(!t3.empty() || !t2.empty()) {
                        if(t3.empty()) {
                            t3.push(t2.peek());
                            System.out.println("Move disk " + t2.peek() + " from " + b + " to " + c);
                            t2.pop();
                        } else {
                            t2.push(t3.peek());
                            System.out.println("Move disk " + t3.peek() + " from " + c + " to " + b);
                            t3.pop();
                        }
                    } 
                }
            }
        }
    }
}
