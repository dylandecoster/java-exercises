/*
Dylan DeCoster
Chapter 10 Excercise 7
Description: Simulate an ATM machine
 */

import java.util.Scanner;

public class Ex7 {
    public static void main(String[] args) {       
        //Makes a new scanner
        Scanner input = new Scanner(System.in);
        //Asks for an id
        System.out.print("Enter an id: ");
        //Gets the id
        Account.id = input.nextInt();

        //If the id is within 0 - 9
        if(Account.id >= 0 && Account.id <= 9){
            //Prints the menu
            System.out.print("Main Menu"
                + "\n1: check balance"
                + "\n2: withdraw"
                + "\n3: deposit"
                + "\n4: exit"
                + "\nEnter a choice: "); 
        }
        else{
            //Asks for the id again
            System.out.println("ID not valid. Please try again");
            Account.id = input.nextInt();
        }
        
        //Gets your choice
        int choice = input.nextInt();
        
        switch (choice) {
            //Gets your accounts current balance
            case 1:
                System.out.println("Your current account balance is $" + Account.getBalance());
                break;
            //Withdraws the given amount
            case 2:
                System.out.println("Enter an amount to withdraw: ");
                Account.withdrawAmount = input.nextInt();
                System.out.println("Your new account balance is $" + (Account.balance - Account.withdrawAmount));
                break;
            //Deposits the given amount
            case 3:
                System.out.println("Enter an amount to deposit: ");
                Account.depositAmount = input.nextInt();
                System.out.println("Your new account balance is $" + (Account.balance + Account.depositAmount));
                break;
            //Exits the program
            case 4:
                System.out.print("Enter an id: ");
                Account.id = input.nextInt();
                break;
            default:
                System.out.println("Not a valid option. Please choose another number.");
                choice = input.nextInt();
                break;
        }
    }
}