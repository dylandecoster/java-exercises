public class Account {
    static int id = 0;
    static double balance = 100;
    static int withdrawAmount = 0;
    static int depositAmount = 0;
    
    //Gets all the info
    public Account(int ID, double bal){
        id = ID;
        balance = bal;
    } 

    public static double getBalance() {
        return balance;
    }
    
    public static void setBalance(double balance) {
        Account.balance = balance;
    }

    public static int getWithdrawAmount() {
        return withdrawAmount;
    }

    public static void setWithdrawAmount(int withdrawAmount) {
        Account.withdrawAmount = withdrawAmount;
    }

    public static int getDepositAmount() {
        return depositAmount;
    }

    public static void setDepositAmount(int depositAmount) {
        Account.depositAmount = depositAmount;
    }
}