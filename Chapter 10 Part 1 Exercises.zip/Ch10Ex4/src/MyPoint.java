public class MyPoint {
    private double x, y;
    
    public MyPoint(){};
    
    public MyPoint(double x, double y){
        //Gets the coordinates
        this.x = x;
        this.y = y;
    }

    //Returns the distance
    public double distance(MyPoint secondPoint){
        return distance(this, secondPoint);
    }
    
    //Finds the distance
    public static double distance(MyPoint p1, MyPoint p2){
        return Math.sqrt((p1.x - p2.x) * (p1.x - p2.x)  + (p1.y - p2.y) * (p1.y - p2.y));
    }

    //Returns y
    public double getY() {
        return y;
    }

    //Returns x
    public void setY(double y) {
        this.y = y;
    }  
}