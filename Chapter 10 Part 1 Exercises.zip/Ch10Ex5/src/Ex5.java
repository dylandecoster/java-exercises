/*
Dylan DeCoster
Chapter 10 Excercise 5
Description: Displays all smallest factors in decreasing order
 */

public class Ex5 {
    public static void main(String[] args) {
        StackOfIntegers stack = new StackOfIntegers();
        //Pushes a new integer into the array
        for(int i = 0; i < 10; i++){
            stack.push(i);
        }
        
        while(!stack.empty()){
            //Removes an integer
            System.out.print(stack.pop() + " ");
        }
    }   
}
