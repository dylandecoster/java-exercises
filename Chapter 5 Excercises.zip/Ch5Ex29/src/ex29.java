/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex29 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
            Scanner input = new Scanner(System.in);
            System.out.print("Enter the year and the first day of the year: ");

            int year = input.nextInt();
            int firstDay = input.nextInt();
            int daysInMonth = 0;

            for(int month = 1; month <= 12; month++){
                System.out.print("          ");
                
                //Changes the month
                switch(month){
                    case 1: System.out.println("January " + year); daysInMonth = 31; break;
                    case 2:  System.out.println("February " + year); 
                        if((year % 400 == 0) || ((year % 4 == 0) && (year % 100 != 0))){
                            daysInMonth = 29;
                        }else{
                            daysInMonth = 28;   
                        }
                    break;
                    case 3:  System.out.println("March " + year); daysInMonth = 31; break;
                    case 4:  System.out.println("April " + year); daysInMonth = 30; break;
                    case 5:  System.out.println("May " + year); daysInMonth = 31; break;
                    case 6:  System.out.println("June " + year); daysInMonth = 30; break;
                    case 7:  System.out.println("July " + year); daysInMonth = 31; break;
                    case 8: System.out.println("August " + year); daysInMonth = 31; break;
                    case 9:  System.out.println("September " + year); daysInMonth = 30; break;
                    case 10:  System.out.println("October " + year); daysInMonth = 31; break;
                    case 11:  System.out.println("November " + year); daysInMonth = 30; break;
                    case 12:  System.out.println("December " + year); daysInMonth = 31; break;
                }
                
                //Formats stuff
                System.out.println("---------------------------------");
                System.out.println(" Sun Mon Tue Wed Thu Fri Sat");                
                
                //Does spacing crap
                for(int k = 0; k < firstDay; k++){
                    System.out.print("    ");
                }
                for(int j = 1; j <= daysInMonth; j++){
                    if(j < 10){
                        System.out.print("   " + j);
                    }
                    else{
                        System.out.print("  " + j);
                    }
                    
                    if((j + firstDay) % 7 == 0){
                        System.out.println();
                    }              
                }
                System.out.println("");
                
                //Resets the week
                firstDay = (firstDay + daysInMonth) % 7;
            }
        }
    }
