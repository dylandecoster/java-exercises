/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //Enter number of students
        System.out.print("Enter the number of students: ");
        int n = input.nextInt();
        
        //Declares a bunch of stuff
        int max = 0;
        int second = 0;
        String maxName = "";
        String secondName = "";

        for(int i = 0; i < n; i++){
            //Gets the inputs of students
            System.out.print("Enter name and score of student " + (i + 1) + ": ");
            String name = input.next();
            int score = input.nextInt();
            
            //Compares scores
            if(score > max){
                second = max;
                secondName = maxName;
                max = score;
                maxName = name;
            }
            else if(score > second){
                second = score;
                secondName = name;
            }
        }
        
        //Prints everything
        System.out.println(maxName + " has the highest score and " + (secondName) + " has the second highest score.");
    }
    
}
