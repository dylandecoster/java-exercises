/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //Lets you input all the crap
        System.out.print("Enter loan amount: ");
        double loanAmount = input.nextDouble();
        System.out.print("Enter number of years: ");
        int numYears = input.nextInt();
        System.out.print("Enter yearly interest rate: ");
        double annualInterest = input.nextDouble();

        //Does some math
        double monthlyInterest = annualInterest / 1200;
        double monthlyRepayment = loanAmount * monthlyInterest / 
                (1 - (Math.pow(1 / (1 + monthlyInterest), numYears * 12)));
        
        //Some variables
        double balance = loanAmount;
        double interest;
        double principal;
        
        //Formats everything and does more math
        System.out.print("Loan Amount: " + loanAmount);
        System.out.println("Number of Years: " + numYears);
        System.out.println("Annual Interest Rate: " + annualInterest + "%");
        System.out.println();
        System.out.println("Monthly Payment: " + (int)(monthlyRepayment * 100) / 100.0);
        System.out.println("Total Payment: " + (int)(monthlyRepayment * 12 * numYears * 100) / 100.0 + "\n");
        
        //Displays the chart thing
        System.out.println("Payment#\tInterest\tPrincipal\tBalance");
        
        //Prints all the stuff
        for(int i = 1; i <= numYears*12; i++){
            interest = (int)(monthlyInterest * balance * 100) / 100.0;
            principal = (int)((monthlyRepayment - interest) * 100) / 100.0;
            balance = (int)((balance - principal) * 100) / 100.0;
            System.out.println(i + "\t\t" + interest + "\t\t" + principal + "\t\t" + balance);
        }
    }
    
}
