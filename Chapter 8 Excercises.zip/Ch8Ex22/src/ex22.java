/*
Dylan DeCoster 
Chapter 8 Excercise 22
Description: Checks for even ones
 */

public class ex22 {
    public static void main(String[] args) {
        int[][] matrix = new int[6][6];
        
        //Makes the matrix
        for(int i = 0; i < matrix.length; i++){
            for(int j = 0; j < matrix[i].length; j++){
                matrix[i][j] = (int)(Math.random() * 2);
                System.out.print(matrix[i][j]);
            }
            System.out.println();
        }
        
        //States the answer
        if(hasEvenOnes(matrix)){
            System.out.println("All rows and columns have even ones");
        }
        else{
            System.out.println("All rows and columns did not have even ones");
        }
    }
    
    public static boolean hasEvenOnes(int[][] matrix){
        //Checks for even ones
        for(int i = 0; i < matrix.length; i++){
            int oneCount = 0;
            for(int j = 0; j < matrix[i].length; j++){
                if(matrix[i][j] == 1){
                    oneCount++;
                }
            }
            if(oneCount % 2 != 0){
                return false;
            }
        }
        
        //Reverses the above loop
        for(int j = 0; j < matrix[0].length; j++){
            int oneCount = 0;
            for(int i = 0; i < matrix.length; i++){
                if(matrix[i][j] == 1){
                    oneCount++;
                }
            }
            
            if(oneCount % 2 != 0){
                return false;
            }
        }
        
        //Returns the method
        return true;
    }
}
