/*
Dylan DeCoster
Chapter 8 Excercise 37
Description: Guess the states capitals
 */

import java.util.Scanner;

public class ex37 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int correct = 0;
        
        //All the states and their capitals
        String[][] arr = new String[][]{
            {"Alabama", "Montgomery"}, 
            {"Alaska", "Juneau"}, 
            {"Arizona", "Phoenix"}, 
            {"Arkansas", "Little Rock"}, 
            {"California", "Sacremento"}   
        };
        
        //Runs through each capital
        for(int i = 0; i < arr.length; i++){
            //Asks the question
            System.out.println("What is the capital of " + arr[i][0] + "?");
            String next = input.nextLine();
            
            //Displays if it is correct or not
            if(next.equals(arr[i][1])){
                System.out.println("Your answer is correct");
                correct++;
            }
            else{
                System.out.println("The correct answer should be " + arr[i][1]);
            }
        }
        
        //Prints the correct count
        System.out.println("The correct count is " + correct);
    }
}