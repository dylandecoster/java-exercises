/*
Dylan DeCoster
Chapter 8 Excercise 16
Description: Sorts a two dimensional array
 */

import java.util.Scanner;

public class ex16 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        //Tells you to enter how big the array is
        System.out.print("Enter number of pairs: ");
        int arr[][] = new int[input.nextInt()][2];
        
        //Lets you input all the numbers in the array
        System.out.print("Enter all the pairs: ");
        for(int i = 0; i < arr.length; i++){
            //Gets the first column
            arr[i][0] = input.nextInt();
            //Gets the second column
            arr[i][1] = input.nextInt();
        }

        //Calls the sort method
        sort(arr);
        
        System.out.print("The array sorted is : ");
        for(int i = 0; i < arr.length; i++){
            //Prints out everything and formats it
            System.out.print("{" + arr[i][0] + ", " + arr[i][1] + "}");
        }
    }
    
    public static void sort(int m[][]){
        for(int i = 0; i < m.length - 1; i++){
            int smallRow = m[i][0];
            int smallCol = m[i][1];
            int index = i;
            
            //Sorts the secondary crap
            for(int j = i + 1; j < m.length; j++){
                if(smallRow > m[j][0]){
                    smallRow = m[j][0];
                    smallCol = m[j][1];
                    index = j;
                }
                else if(smallRow == m[j][0] && smallCol > m[j][1]){
                    smallCol = m[j][1];
                    index = j;
                }
            }
            
            if(index != i){
                m[index][0] = m[i][0];
                m[i][0] = smallRow;
                m[index][1] = m[i][1];
                m[i][1] = smallCol;
            }
        }     
    }
}