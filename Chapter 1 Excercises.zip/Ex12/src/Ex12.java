/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
public class Ex12 {
    public static void main(String[] args){
        System.out.println((24*1.6)/(1+(40 + (35.0/60))/60));
    }
}
