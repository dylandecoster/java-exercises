/*
Dylan DeCoster
Chapter 12 Exercise 15
Write a program to write 100 integers to a file and print them in ascending order
 */
import java.io.*;
import java.util.*;
public class ex15 {
    public static void main(String[] args) throws Exception {
        File file = new File("Exercise12_15.txt"); // Creates a new file
        PrintWriter output = new PrintWriter(file); // Creates a PrintWriter to write the integers to the file
        
        if(file.exists()) { // Checks to see if the file exists
            for (int i = 0; i < 100; i++) {
                // Puts all the numbers into a file
                Random rand = new Random();
                output.print(rand.nextInt(100) + " ");
            }
            output.close();
        }

        Scanner input = new Scanner(file); // Creates a scanner connected to the file
        ArrayList<Integer> numbers = new ArrayList<>(); // Creates an array list so we can sort the integers
        
        // Adds all the numbers into the array list
        for (int i = 0; i < 100; i++) {
            if(input.hasNextInt()) 
                numbers.add(input.nextInt());
        }
        
        Collections.sort(numbers); // Sorts the array list
        System.out.println(numbers); // Displays the array list
    }
    
}
