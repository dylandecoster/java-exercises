/*
Dylan DeCoster
Chapter 12 Exercise 25
Write a program that reads through a file and gets the salary of various faculty.
 */

import java.io.*;
import java.util.*;
public class ex25 {
    public static void main(String[] args) throws Exception{
        File file = new File("Salary.txt"); // Creates a new file from the text document
        Scanner input = new Scanner(file); // Reads the file
        
        double assistant = 0, associate = 0, full = 0, total = 0; // Initializes all the variables for the job types
        int assistantCount = 0, associateCount = 0, fullCount = 0;
        
        while(input.hasNextLine()) { // Reads a whole line
            String next = input.next(); // Reads each word in the line
            if(next.equals("assistant")) {
                assistant += Double.parseDouble(input.next());
                assistantCount++;
            } else if(next.equals("associate")) {
                associate += Double.parseDouble(input.next());
                associateCount++;
            } else if(next.equals("full")) {
                full += Double.parseDouble(input.next());
                fullCount++;
            }
        }
        
        total = assistant + associate + full;
        
        System.out.println("Total salary for assistants: $" + String.format("%.2f", assistant));
        System.out.println("Total salary for associates: $" + String.format("%.2f", associate));
        System.out.println("Total salary for full professors: $" + String.format("%.2f", full));
        System.out.print("Total salary for all faculty: $" + String.format("%.2f", total));
        System.out.println("\n");
        System.out.println("Average salary for assistants: $" + String.format("%.2f", assistant / assistantCount));
        System.out.println("Average salary for associates: $" + String.format("%.2f", associate / associateCount));
        System.out.println("Average salary for full professors: $" + String.format("%.2f", full / fullCount));
        System.out.println("Average salary for all faculty: $" + String.format("%.2f", total / 1000));
    }
}
