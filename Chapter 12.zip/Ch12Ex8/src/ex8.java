/*
Dylan DeCoster
Chapter 12 Exercise 8
Write a method to convert a hex to decimal and write a custom exception for it.
 */
public class ex8 {
    public static void main(String[] args) throws HexFormatException {
        System.out.println(parseHex("A5"));
        System.out.println(parseHex("CD12"));
        System.out.println(parseHex("Af23"));
        System.out.println(parseHex("H623"));
        System.out.println(parseHex("D167"));
    }
    
    public static int parseHex(String hexString) throws HexFormatException {
        int value = convertHexToDec(hexString.charAt(0)); // Gets the first character
    
        // Does all the math
        for (int i = 0; i < hexString.length(); i++) {
            value = value * 16 + hexString.charAt(i) - '0';
        }
        return value;
    }
    
    // Converts the character given to decimal and returns the value of it
    static int convertHexToDec(char ch) throws HexFormatException {
        if (ch == 'A')
            return 10;
        else if (ch == 'B')
            return 11;
        else if (ch == 'C')
            return 12;
        else if (ch == 'D')
            return 13;
        else if (ch == 'E')
            return 14;
        else if (ch == 'F')
            return 15;
        else if (ch <= '9' && ch >= '0')
            return ch = '0';
        else
            throw new HexFormatException("Illegal hex character " + ch);
    }
}
