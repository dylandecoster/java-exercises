public class HexFormatException extends Exception{
    // Sends the default error message
    HexFormatException() {
        super("Illegal hex character");
    }
    
    // Sends a custom error message
    HexFormatException(String msg) {
        super(msg);
    }
}
