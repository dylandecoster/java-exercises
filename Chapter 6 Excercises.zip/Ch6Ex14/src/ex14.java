/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
public class ex14 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Formats
        System.out.println("i\t\tm(i)");
        //Prints everything
        for(int i = 10; i <= 100; i += 10){
            System.out.println(i + "\t\t" + m(i));
        }
    }
    
    public static double m(int n){
        double pi = 0;
        double term;
        
        //Does the math
        for(int i = 1; i <= n; i += 2){
            term = 4.0 * (1.0 / (2 * i - 1) - 1.0 / (2 * i + 1));
            pi += term;
        }
        
        //Returns pi
        return pi;
    }
}
