/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter n: ");
        int num = input.nextInt();
        
        printMatrix(num);
    }
    
    public static void printMatrix(int n){
        //Prints a new line every time the for loop below runs
        for(int i = 1; i <= n; i++){
            //Prints the number n times on one line
            for(int j = 1; j <= n; j++){
                System.out.print(Math.round(Math.random()) + " ");
            }
            System.out.println();
        }
    }
}
