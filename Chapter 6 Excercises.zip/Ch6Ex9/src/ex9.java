/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
public class ex9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        float feet = 1;
        float meter = 20;
        
        //Formats stuff
        System.out.println("Feet\t\tMeters\t\t|\tMeters\t\tFeet\t\t");
        System.out.println("__________________________________________________________________");
        
        //Prints the chart
        for(int i = 1; i <= 10; i++){
            System.out.println(feet + "\t\t" + footToMeter(feet) + "\t\t|\t"
                    + meter + "\t\t" + meterToFoot(meter));
            
            feet++;
            meter += 5;
        }
        
    }
    
    //Converts feet to meters
    public static double footToMeter(double foot){
        foot *= 0.305;        
        return foot;
    }
    
    //Converts meters to feet
    public static double meterToFoot(double meter){
        meter *= 3.279;       
        return meter;
    }
}
