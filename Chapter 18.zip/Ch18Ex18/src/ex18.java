/*
Dylan DeCoster
Chapter 18 Exercise 18
Modify the Tower of Hanoi project
 */

import java.util.Scanner;

public class ex18 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.print("Enter number of disks: ");
        int n = input.nextInt();
        
        System.out.println("The moves are: ");
        moveDisks(n, 'A', 'B', 'C');
        System.out.println(i);
    }
    
    public static int i = 0;
    public static void moveDisks(int n, char fromTower, char toTower, char auxTower) {
        if(n == 1)
            i++;
        else {
            // Moves the disks
            moveDisks(n - 1, fromTower, auxTower, toTower);
            i++;
            moveDisks(n - 1, auxTower, toTower, fromTower);
        }
    }
}
