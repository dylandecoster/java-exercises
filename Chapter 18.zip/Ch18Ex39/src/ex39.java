/*
Dylan DeCoster
Chapter 18 Exercise 39
Write a program that creates a tree
 */

import javafx.application.Application;
import javafx.scene.layout.Pane;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class ex39 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        // Sets up the text field and label
        HBox hBox = new HBox(10);
        TextField tfOrder = new TextField();
        tfOrder.setPrefColumnCount(4);
        tfOrder.setAlignment(Pos.BOTTOM_RIGHT);
        hBox.getChildren().addAll(new Label("Enter an order: "), tfOrder);
        hBox.setAlignment(Pos.CENTER);
        
        // Creates a new tree instance
        TreePane tree = new TreePane();
        tfOrder.setOnAction(e -> {
            tree.setDepth(Integer.parseInt(tfOrder.getText()));
        });
        
        // Positions everything
        BorderPane pane = new BorderPane();
        pane.setBottom(hBox);
        pane.setCenter(tree);
        
        Scene scene = new Scene(pane, 300, 250);
        
        primaryStage.setTitle("Exercise 18.39");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    static class TreePane extends Pane{
        private int depth = 0;
        private final double angleFactor = Math.PI / 5, sizeFactor = 0.58;
    
        // Changes the size of the tree when you change the depth
        public void setDepth(int depth) {
            this.depth = depth;
            paint();
        }
        
        // Clears all the branches to create a new tree
        public void paint() {
            getChildren().clear();
            paintBranch(depth, getWidth()/2, getHeight()-10, getHeight()/3, Math.PI/2);
        }
        
        public void paintBranch(int depth, double x1, double y1, double length, double angle) {
            if(depth >= 0) {
                // Creates branched that go in opposite directions
                double x2 = x1 + Math.cos(angle) * length;
                double y2 = y1 - Math.sin(angle) * length;
                
                getChildren().add(new Line(x1, y1, x2, y2));
                
                // Creates the new branches
                paintBranch(depth-1, x2, y2, length*sizeFactor, angle+angleFactor);
                paintBranch(depth-1, x2, y2, length*sizeFactor, angle-angleFactor);
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
