/*
Dylan DeCoster
Chapter 18 Exercise 35
Develop an H-Tree
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.stage.Stage;

public class ex35 extends Application {
    Pane pane = new Pane();
    
    @Override
    public void start(Stage primaryStage) {
        // Default H
        Line line1 = new Line(100, 75, 100, 175);
        Line line2 = new Line(200, 75, 200, 175);
        Line line3 = new Line(100, 125, 200, 125);
        pane.getChildren().addAll(line1, line2, line3);
        
        // Creates the default method call
        makeH(5, line1, line2, 1, 25);
        
        Scene scene = new Scene(pane, 300, 250);
        
        primaryStage.setTitle("Exercise 18.35");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void makeH(int n, Line line1, Line line2, int i, int size) {
        if(n > 1) {
            // Creates 4 different H's based on the previous ones points
            Line L1 = new Line(line1.getStartX() - size, line1.getStartY() - size, line1.getStartX() - size, line1.getStartY() + size);
            Line L2 = new Line(line1.getStartX() + size, line1.getStartY() - size, line1.getStartX() + size, line1.getStartY() + size);
            Line L3 = new Line(line1.getStartX() + size, line1.getStartY() - size + size, line1.getStartX() - size, line1.getStartY() - size + size);

            Line L4 = new Line(line1.getEndX() - size, line1.getEndY() - size, line1.getEndX() - size, line1.getEndY() + size);
            Line L5 = new Line(line1.getEndX() + size, line1.getEndY() - size, line1.getEndX() + size, line1.getEndY() + size);
            Line L6 = new Line(line1.getEndX() + size, line1.getEndY() - size + size, line1.getEndX() - size, line1.getEndY() - size + size);
            
            Line L7 = new Line(line2.getStartX() - size, line2.getStartY() - size, line2.getStartX() - size, line2.getStartY() + size);
            Line L8 = new Line(line2.getStartX() + size, line2.getStartY() - size, line2.getStartX() + size, line2.getStartY() + size);
            Line L9 = new Line(line2.getStartX() + size, line2.getStartY() - size + size, line2.getStartX() - size, line2.getStartY() - size + size);

            Line L10 = new Line(line2.getEndX() - size, line2.getEndY() - size, line2.getEndX() - size, line2.getEndY() + size);
            Line L11 = new Line(line2.getEndX() + size, line2.getEndY() - size, line2.getEndX() + size, line2.getEndY() + size);
            Line L12 = new Line(line2.getEndX() + size, line2.getEndY() - size + size, line2.getEndX() - size, line2.getEndY() - size + size);
                
            // Adds all the points into the pane
            pane.getChildren().addAll(L1, L2, L3, L4, L5, L6, L7, L8, L9, L10, L11, L12);
  
            // Makes four seperate H's for each H
            makeH(n-1, L1, L2, 2, size/2);
            makeH(n-1, L4, L5, 3, size/2);
            makeH(n-1, L7, L8, 4, size/2); 
            makeH(n-1, L10, L11, 0, size/2);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
