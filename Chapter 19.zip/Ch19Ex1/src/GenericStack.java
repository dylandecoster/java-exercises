/*
Dylan DeCoster
Chapter 19 Exercise 1
Replace the ArrayList with an Array
 */

import java.util.Arrays;

public class GenericStack<E> {
    private E[] arr = (E[])new Object[10];
    private int size;
    
    public int getSize() { return arr.length; } // Returns number of elements in the stack
    public E peek() { return arr[getSize() - 1]; } // Return the top element of stack
    
    // Adds new element to top of stack
    public void push(E o) {
        arr[size++] = o;
        E[] temp = (E[])new Object[getSize() * 2];
        System.arraycopy(arr, 0, temp, 0, arr.length);
        arr = temp;
    }
    
    // Returns and removes the top element of the stack
    public E pop() {
        if(size == 0) return null;
        else return arr[size--];
    }
        
    public boolean isEmpty() { return size == 0; } // Return whether the stack is empty or not
    
    @Override
    public String toString() { return "stack: " + Arrays.toString(arr); }
    
    public static void main(String[] args) {
        GenericStack<String> stack1 = new GenericStack<>();
        stack1.push("London");
        stack1.push("Paris");
        stack1.push("Berlin");
        System.out.println(stack1.toString());
    }
    
}
