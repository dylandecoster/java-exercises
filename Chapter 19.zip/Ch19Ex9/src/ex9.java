/*
Dylan DeCoster
Chapter 19 Exercise 9
Sort an array list
 */

import java.util.ArrayList;
import java.util.Collections;

public class ex9 {
    public static void main(String[] args) {
        ArrayList<String> arr = new ArrayList<>();
        arr.add("Billy");
        arr.add("Abraham");
        arr.add("Dylan");
        arr.add("Chad");
        sort(arr);
    }
    
    public static <E extends Comparable<E>> void sort(ArrayList<E> list) {
        System.out.println("Unsorted: " + list);
        Collections.sort(list); // Sorts the list
        System.out.println("Sorted: " + list); // Prints the sorted list
    }
}
