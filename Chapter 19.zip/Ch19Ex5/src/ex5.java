/*
Dylan DeCoster
Chapter 19 Exercise 5
Create a method that returns that maximum element in an array
 */

import java.util.Arrays;

public class ex5<E extends Comparable<E>> {
    public static void main(String[] args) {
        Integer[] arr = new Integer[]{1, 5, 7, 1, 2, 9, 8, 2, 3, 4}; // Creates an array
        System.out.println(max(arr)); // Returns the max
    }
    
    public static <E extends Comparable<E>> E max(E[] list) {
        E temp = list[0]; // Sets the default value
        for(int i = 0; i < list.length; i++) {
            // Gets the bigger number
            if(list[i].compareTo(temp) > 0) {
                temp = list[i]; // Sets temp to the bigger number
            }
        }
        
        return temp;
    }
}
