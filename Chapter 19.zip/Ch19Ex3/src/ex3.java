/*
Dylan DeCoster
Chapter 19 Exercise 3
Create a method that returns an arraylist with no duplicates
 */

import java.util.ArrayList;
public class ex3<E> {
    public static void main(String[] args) {
        ArrayList<String> test = new ArrayList<>();
        test.add(0, "Apple");
        test.add(1, "Apple");
        test.add(2, "Banana");
        test.add(3, "Orange");
        test.add(4, "Apple");
        test.add(5, "Peach");
        test.add(6, "Apple");
        test.add(7, "Banana");
        test.add(8, "Orange");
        test.add(9, "Peach");
        System.out.println(removeDuplicates(test));
    }
    
    public static <E> ArrayList <E> removeDuplicates(ArrayList<E> list) {
        ArrayList<E> newList = new ArrayList<E>();
        newList.add(list.get(0)); // Sets the first item of the list
        
        // Changes the current item
         for(int i = 1; i < list.size(); i++) {
            boolean isDuplicate = false;
            
            // Checks every item in the new list
            for(int j = 0; j < newList.size(); j++) {
                // If it finds a duplicate
                if(newList.get(j) == list.get(i))
                    isDuplicate = true;
            }
            
            // If it couldn't find a duplicate
            if(isDuplicate == false)
                newList.add(list.get(i)); // Adds the item to the list
        }
        
        return newList;
    }
}
