/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex17 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        System.out.println("scissor (0), rock (1), paper (2): ");
        int num = input.nextInt();
        int random = (int)(Math.random() * 3);
        
        if(num == 0 && random == 0)
            System.out.println("The computer is scissor. You are scissor too. It is a draw.");
        else if(num == 0 && random == 1)
            System.out.println("The computer is rock. You are scissor. You lost.");
        else if(num == 0 && random == 2)
            System.out.println("The computer is paper. You are scissor. You won.");
        
        if(num == 1 && random == 0)
            System.out.println("The computer is scissor. You are rock. You won.");
        else if(num == 1 && random == 1)
            System.out.println("The computer is rock. You are rock too. It is a draw.");
        else if(num == 1 && random == 2)
            System.out.println("The computer is paper. You are rock. You lost.");
        
        if(num == 2 && random == 0)
            System.out.println("The computer is scissor. You are paper. You lost.");
        else if(num == 2 && random == 1)
            System.out.println("The computer is rock. You are paper. You won.");
        else if(num == 2 && random == 2)
            System.out.println("The computer is paper. You are paper too. It is a draw.");
    }
    
}
