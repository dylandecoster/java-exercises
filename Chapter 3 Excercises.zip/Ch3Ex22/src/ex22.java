/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex22 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter a point with two coordinates: ");
        double x = input.nextDouble();
        double y = input.nextDouble();
        
        double distance = Math.pow(x*x + y*y, 0.5);
        
        if(distance <= 10)
            System.out.println("Point (" + x + ", " + y + ") is in the circle");
        else
            System.out.println("Point (" + x + ", " + y + ") is not in the circle");
    }
    
}
