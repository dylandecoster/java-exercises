/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner input = new Scanner(System.in);
        System.out.println("Enter today's day: ");
        int dayInt = input.nextInt();
        System.out.println("Enter the number of days elapsed since today: ");
        
        int daysElapsed = input.nextInt();

        
        if(daysElapsed > 7){
            daysElapsed %= 7;
        }
        else{
            daysElapsed++;
        }
        
        String day = null;
        String str = null;
        
        switch (dayInt){
            case 0: day = "Sunday"; break;
            case 1: day = "Monday"; break;
            case 2: day = "Tuesday"; break;
            case 3: day = "Wednesday"; break;
            case 4: day = "Thursday"; break;
            case 5: day = "Friday"; break;
            case 6: day = "Saturday"; break;
        }
        
        switch (daysElapsed){
            case 0: str = "Sunday"; break;
            case 1: str = "Monday"; break;
            case 2: str = "Tuesday"; break;
            case 3: str = "Wednesday"; break;
            case 4: str = "Thursday"; break;
            case 5: str = "Friday"; break;
            case 6: str = "Saturday"; break;
        }
        
        System.out.println("Today is " + day + " and the future day is " + str);
    }            
    
}
