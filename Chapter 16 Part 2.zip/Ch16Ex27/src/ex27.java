/*
Dylan DeCoster
Chapter 16 Exercise 27
Display country flag and description
 */

import java.io.*;
import java.util.Scanner;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;

public class ex27 extends Application {
    private String[] flagTitles = {"Canada", "China", "Denmark", "France", "Germany", "India", "Norway", "United Kingdom", "Unites States"};
    private ImageView[] flagImages = {
        new ImageView("/img/canada.jpg"),
        new ImageView("/img/china.png"),
        new ImageView("/img/denmark.jpg"),
        new ImageView("/img/france.jpg"),
        new ImageView("/img/germany.jpg"),
        new ImageView("/img/india.png"),
        new ImageView("/img/norway.jpg"),
        new ImageView("/img/uk.jpg"),
        new ImageView("/img/us.jpg")
    };

    private ComboBox<String> combo = new ComboBox<>();
    final TextArea desc = new TextArea("Description of Canada");
    BorderPane pane = new BorderPane();
    
    @Override
    public void start(Stage primaryStage) throws FileNotFoundException {
        setDisplay(0); // Sets the default display
        
        // Creates the combo box and positions it
        BorderPane cbPane = new BorderPane();
        cbPane.setLeft(new Label("Select a country: "));
        cbPane.setCenter(combo);
        pane.setTop(cbPane);
        combo.setPrefWidth(400);
        combo.setValue("Canada");

        // Adds all the flag titles to the combo box
        ObservableList<String> items =
                FXCollections.observableArrayList(flagTitles);
        combo.getItems().addAll(items);

        // Changes the country
        combo.setOnAction(e -> {
            try {
                setDisplay(items.indexOf(combo.getValue()));
            } catch (Exception ex) {
                desc.setText("I messed up somewhere");
            }
        });
        
        Scene scene = new Scene(pane, 450, 170);
        primaryStage.setTitle("Exercise 16.27");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    void setDisplay(int index) throws FileNotFoundException {
        // Reads the correct description from a file
        Scanner scanner = new Scanner(new File("D:\\MNTC\\Java\\Java II Exercises\\Ch16Ex27\\src\\desc.txt"));
        String getDesc = "";
        for(int i = 0; i <= index; i++) {
            getDesc = scanner.nextLine();
        }
        desc.setText(getDesc);
        
        // Positions the description
        desc.setPrefWidth(225);
        desc.setWrapText(true);
        desc.setEditable(false);
        pane.setRight(desc);
        
        // Positions the image
        flagImages[index].setFitHeight(120);
        flagImages[index].setFitWidth(225);
        pane.setLeft(flagImages[index]);

        pane.setBottom(new Label(flagTitles[index]));
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
