/*
Dylan DeCoster
Chapter 16 Exercise 31
Create a connect 4 game
 */
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;

public class ex31 extends Application {
    GridPane pane = new GridPane();
    int colorNum = 2;
    
    // 0 = EMPTY, 1 = RED, 2 = YELLOW
    int[][] circles = { // Stores a map of the circles
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0},
        {0, 0, 0, 0, 0, 0, 0}
    };
    
    @Override
    public void start(Stage primaryStage) {
        createGUI();
        play();

        Scene scene = new Scene(pane, 500, 430);
        scene.setFill(Color.LIGHTBLUE);
        primaryStage.setTitle("Exercise 31");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    void createGUI() {
        pane.setVgap(10);
        pane.setHgap(10);
        pane.setPadding(new Insets(10, 10, 10, 10));
        
        for(int i = 0; i < 7; i++) {
            for(int j = 0; j < 6; j++) {
                pane.add(new Circle(30, Color.WHITE), i, j);
            }
        }
    }
    
    void play() {
        pane.setOnMouseReleased(e -> {
            int column = (int)(e.getX() / 70); // Gets the column number
            for(int i = 5; i >= 0; i--) {
                if(circles[i][column] == 0) {
                    pane.add(new Circle(30, switchColor()), column, i); // Creates a new circle and switches colors on the column clicked
                    circles[i][column] = colorNum; // Fills the array with the new circles color
                    break;
                }
            }

            checkScore();
             
            // Prints the grid of circles and whats occupied
//            for(int i = 0; i < 6; i++) { // ROW
//                for(int j = 0; j < 7; j++) { // COLUMN
//                    System.out.print(circles[i][j] + " ");
//                }
//                System.out.println();
//            }
//            System.out.println();
        });
    }

    void checkScore() {
        // Rows
        for(int i = 0; i < 6; i++) { // ROW
            for(int j = 0; j < 4; j++) { // COLUMN -- Checks the first four columns
                int inRow = 1;

                if(circles[i][j] == colorNum) { // Gets the first circle in the row
                    for(int k = 1; k <= 3; k++) { // Checks the next 3 circles
                        if(circles[i][j + k] == colorNum) {
                            inRow+=1;
                        }
                    } 
                }

                if(inRow == 4) 
                    endGame(i, j, 1);
            }
        }
            
        // Columns
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 7; j++) {
                int inRow = 1;

                if(circles[i][j] == colorNum) {
                    for(int k = 1; k <= 3; k++) {
                        if(circles[i + k][j] == colorNum) {
                            inRow += 1;
                        }
                    }
                }

                if(inRow == 4)
                    endGame(i, j, 2);
            }
        }

        // Diagonal Down
        for(int i = 0; i < 3; i++) {
            for(int j = 0; j < 4; j++) {
                int inRow = 1;

                if(circles[i][j] == colorNum) {
                    for(int k = 1; k <= 3; k++) {
                        if((i > 0 && i < 6) && (j > 0 && j < 7)) {
                            if(circles[i + k][j + k] == colorNum) {
                                inRow += 1;
                            } else {
                                break;
                            }
                        }
                        
                        if(inRow == 4)
                            endGame(i, j, 3);
                    }
                }
            }
        }
        
        // Diagonal Up
        for(int i = 0; i < 6; i++) {
            for(int j = 0; j < 4; j++) {
                int inRow = 1;

                if(circles[i][j] == colorNum) {
                    for(int k = 1; k <= 3; k++) {
                        if((i > 0 && i < 6) && (j > 0 && j < 7)) {
                            if(circles[i - k][j + k] == colorNum) {
                                inRow += 1;
                            } else {
                                break;
                            }
                        }
                        
                        if(inRow == 4)
                            endGame(i, j, 4);
                    }
                }
            }
        }
    }
    
    void endGame(int i, int j, int type) {
        System.out.println(getColor() + " WINS");
        
        for(int k = 0; k < 4; k++) { // Repeats for every circle
            switch(type) { // Gets the type of four in a row
                case 1: pane.add(new Circle(30, Color.VIOLET), j + k, i); break; // ROW
                case 2: pane.add(new Circle(30, Color.VIOLET), j, i + k); break; // COLUMN
                case 3: pane.add(new Circle(30, Color.VIOLET), j + k, i + k); break; // DIAGONAL DOWN
                case 4: pane.add(new Circle(30, Color.VIOLET), j + k, i - k); break; // DIAGONAL UP
            }
        }
        
        pane.setOnMouseReleased(null); // Stops reading input
    }
    
    Color switchColor() {
        if(colorNum == 1){
            colorNum = 2;
            return Color.YELLOW;
        }
        colorNum = 1;
        return Color.RED;
    }
    
    String getColor() {
        if(colorNum == 1)
            return "RED";
        return "YELLOW";
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
