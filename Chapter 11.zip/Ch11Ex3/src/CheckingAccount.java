public class CheckingAccount extends Account{
    public CheckingAccount(int ID, double bal, double annualInterest) {
        super(ID, bal, annualInterest);
    }
    
    public String toString() {
        //Checks to see if the account will be overdrawn
        if (Account.balance < 0) {
            return "Checking account cannot be overdrawn";
        }
        return "Your checking account balance is " + Account.balance;
    }
}
