/*
Dylan DeCoster
Chapter 11 Exercise 3
Description: Create and test a checkings and savings account
 */
public class ex3 {
    public static void main(String[] args) {
        //Creates a new account and prints the balance
        Account acc = new Account(1000, 2000, 3000);
        System.out.println(acc.toString());
        
        //Creates a checkings account and withdraws money from it
        CheckingAccount acc2 = new CheckingAccount(2, 3, 4);
        Account.withdraw();
        System.out.println(acc2.toString());
        
        //Creates a savings account and prints out the balance
        SavingsAccount acc3 = new SavingsAccount(1, 3, 5);
        System.out.println(acc3.toString());
    }
}
