public class SavingsAccount extends Account{
    public SavingsAccount(int ID, double bal, double annualInterest) {
        super(ID, bal, annualInterest);
    }
    
    //Returns the savings account balance
    public String toString() {
        return "Your savings account balance is " + Account.balance;
    }
}
