class Account {
    public static int id = 0;
    public static double balance = 0, annualInterestRate = 0;
    
    //Gets all the info
    public Account(int ID, double bal, double annualInterest){
        this.id = ID;
        this.balance = bal;
        this.annualInterestRate = annualInterest;
    }

    //Returns the monthly interest rate
    public static double getMonthlyInterestRate(){
        return (annualInterestRate / 100) / 12;
    }
    
    //Returns the monthly interest
    public static double getMonthlyInterest(){
        return balance * getMonthlyInterestRate();
    }
    
    //Withdraws 2500
    public static void withdraw(){
        balance -= 2500;
    }
    
    //Deposits 3000
    public static void deposit(){
        balance += 3000;
    }
    
    //Returns the current account balance
    public String toString() {
        return "Your account balance is " + balance;
    }
}
