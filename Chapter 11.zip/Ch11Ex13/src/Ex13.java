/*
Name: Dylan DeCoster
Project: Chapter 11 Exercise 13
Description: Create two subclasses for checking and savings accounts
 */
import java.util.*;
public class Ex13 {
    public static void main(String[] args) {
        // Creates an array list
        ArrayList numbers = new ArrayList();
        
        // Gets the users input
        Scanner input = new Scanner(System.in);
        System.out.println("Enter 10 integers: ");
        for(int i=0; i < 10; i++) {
            numbers.add(input.nextInt());
        }
        
        // Prints the new integers without duplicates
        System.out.println("The distinct integers are " + removeDuplicate(numbers));
    }
    
    public static String removeDuplicate(ArrayList<Integer> list) {
        // Creates an empty string
        String str = "";
        
        // Checks for duplicates
        for(int i = 0; i < list.size(); i++) {
            for(int j = 0; j < i; j++) {
                // If there is a duplicate it skips it
                if(list.get(i) == list.get(j)) {
                    i++;
                }
            }
            // Adds the integer to the new string
            str += list.get(i) + " ";
        }
        // Returns the new list
        return str;
    }
}
