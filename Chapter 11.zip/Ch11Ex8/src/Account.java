/*
    Dylan DeCoster
    Chapter 11 Exercise 8
    Create the Transactions class and set it up
*/

import java.util.ArrayList;

class Account {
    public static int id = 0;
    public static double balance = 0, annualInterestRate = 0;
    private java.util.Date dateCreated;
    private String name;
    java.util.ArrayList transactions = new java.util.ArrayList();
    
    public Account() {
        dateCreated = new java.util.Date();
    }
    
    //Gets all the info
    public Account(int ID, double bal){
        id = ID;
        balance = bal;
        dateCreated = new java.util.Date();
    }
    
    public Account(int ID, double bal, String name){
        id = ID;
        balance = bal;
        this.name = name;
        dateCreated = new java.util.Date();
    }

    // ALL the getters and setters
    public ArrayList getTransactions() {
        return transactions;
    }
    public void setTransactions(ArrayList transactions) {
        this.transactions = transactions;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public int getID() {
        return this.id;
    }
    public double getBalance() {
        return balance;
    }
    public static double getAnnualInterestRate() {
        return annualInterestRate;
    }
    public void setId(int newID) {
        id = newID;
    }
    public void setBalance(double newBalance) {
        balance = newBalance;
    }
    public static void setAnnualInterestRate(double newAnnualInterestRate) {
        annualInterestRate = newAnnualInterestRate;
    }
    public static double getMonthlyInterestRate(){
        return (annualInterestRate / 100) / 12;
    }
    public static double getMonthlyInterest(){
        return balance * getMonthlyInterestRate();
    }
    public java.util.Date getDateCreated() {
        return dateCreated;
    }

    //Withdraws 2500
    public void withdraw(){
        balance -= 2500;
        transactions.add(new Transaction('W', 2500, balance, ""));
    }
    
    //Deposits 3000
    public void deposit(){
        balance += 3000;
        transactions.add(new Transaction('D', 2500, balance, ""));
    }
    
    public static void main(String[] args) {
        Account acc = new Account(12, 100, "Jeff");
        acc.deposit();
        
        acc.withdraw();
        
        System.out.println("Name: " + acc.getName() + 
                "\nAnnual Interest Rate: " + acc.getAnnualInterestRate() + 
                "\nBalance: " + acc.getBalance());
        
        System.out.printf("%-35s%-15s%-15s%-15s\n", "Date", "Type", "Amount", "Balance");
        
        java.util.ArrayList list = acc.getTransactions();
        for(int i = 0; i < list.size(); i++) {
            Transaction t = (Transaction) list.get(i);
            System.out.printf("%-35s%-15s%-15s%-15s\n", t.getDate(), t.getType(), t.getAmount(), t.getBalance());
        }
    }
}
