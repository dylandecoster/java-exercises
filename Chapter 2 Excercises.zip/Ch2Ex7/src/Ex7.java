/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class Ex7 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter the number of minutes: ");
        int minutes = input.nextInt();
        int days = minutes / 60 / 24;
        int years = days / 365;
        days %= 365;
        
        System.out.println(minutes + " minutes is approximately " + years + " years and " + days + " days");
    }
}
