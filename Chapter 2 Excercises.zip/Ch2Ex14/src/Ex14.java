/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class Ex14 {
    public static void main(String[] args){
        Scanner input = new Scanner(System.in);
        
        System.out.println("Enter weight in pounds: ");
        float pounds = input.nextFloat();
        
        System.out.println("Enter height in inches: ");
        float inches = input.nextFloat();
        
        pounds *= 0.45359237;
        inches *= 0.0254;
        float bmi = (float)(pounds / Math.pow(inches, 2));
        
        System.out.println("BMI is " + bmi);
    }
}
