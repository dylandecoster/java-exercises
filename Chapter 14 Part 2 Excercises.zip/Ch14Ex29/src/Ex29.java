/*
Dylan DeCoster
Chapter 14 Excercise 29
Description: Make a bean machine
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polyline;

public class Ex29 extends Application{
    @Override
    public void start(Stage primaryStage){
        Pane pane = new Pane();
        pane.setPadding(new Insets(100, 100, 100, 100));
        
        //Makes the base shape
        Polyline line = new Polyline();
        line.getPoints().addAll(new Double[]{
            500.0, 50.0,
            500.0, 100.0,
            400.0, 300.0,
            400.0, 375.0,
            650.0, 375.0,
            650.0, 300.0,
            550.0, 100.0,
            550.0, 50.0
        });
        
        //Makes all of the slots
        Line slot1 = new Line(431.25, 300.0, 431.25, 375.0);
        Line slot2 = new Line(462.5, 300.0, 462.5, 375.0);
        Line slot3 = new Line(493.75, 300.0, 493.75, 375.0);
        Line slot4 = new Line(525, 300.0, 525, 375.0);
        Line slot5 = new Line(556.25, 300.0, 556.25, 375.0);
        Line slot6 = new Line(587.5, 300.0, 587.5, 375.0);
        Line slot7 = new Line(618.75, 300.0, 618.75, 375.0);
        //Makes the first row of dots
        Circle dot1 = new Circle(431.25, 300, 5);
        Circle dot2 = new Circle(462.5, 300, 5);
        Circle dot3 = new Circle(493.75, 300, 5);
        Circle dot4 = new Circle(525, 300, 5);
        Circle dot5 = new Circle(556.25, 300, 5);
        Circle dot6 = new Circle(587.5, 300, 5);
        Circle dot7 = new Circle(618.75, 300, 5);
        //Second row of dots
        Circle dot8 = new Circle(435.7, 275, 5);
        Circle dot9 = new Circle(471.4, 275, 5);
        Circle dot10 = new Circle(507.1, 275, 5);
        Circle dot11 = new Circle(542.8, 275, 5);
        Circle dot12 = new Circle(578.5, 275, 5);
        Circle dot13 = new Circle(614.2, 275, 5);
        //Third row of dots
        Circle dot14 = new Circle(445, 250, 5);
        Circle dot15 = new Circle(483.26, 250, 5);
        Circle dot16 = new Circle(524.86, 250, 5);
        Circle dot17 = new Circle(566.46, 250, 5);
        Circle dot18 = new Circle(600, 250, 5);
        //Sixth row of dots
        Circle dot19 = new Circle(460, 225, 5);
        Circle dot20 = new Circle(500, 225, 5);
        Circle dot21 = new Circle(550, 225, 5);
        Circle dot22 = new Circle(590, 225, 5);
        //Seventh row
        Circle dot23 = new Circle(475, 200, 5);
        Circle dot24 = new Circle(525, 200, 5);
        Circle dot25 = new Circle(575, 200, 5);
        //Eighth row
        Circle dot26 = new Circle(500, 175, 5);
        Circle dot27 = new Circle(550, 175, 5);
        //Ninth row
        Circle dot28 = new Circle(525, 150, 5);
        
        pane.getChildren().add(line);
        pane.getChildren().add(slot1);
        pane.getChildren().add(slot2);
        pane.getChildren().add(slot3);
        pane.getChildren().add(slot4);
        pane.getChildren().add(slot5);
        pane.getChildren().add(slot6);
        pane.getChildren().add(slot7);   
        pane.getChildren().add(dot1);
        pane.getChildren().add(dot2);
        pane.getChildren().add(dot3);
        pane.getChildren().add(dot4);
        pane.getChildren().add(dot5);
        pane.getChildren().add(dot6);
        pane.getChildren().add(dot7);        
        pane.getChildren().add(dot8);
        pane.getChildren().add(dot9);
        pane.getChildren().add(dot10);
        pane.getChildren().add(dot11);
        pane.getChildren().add(dot12);
        pane.getChildren().add(dot13);       
        pane.getChildren().add(dot14);
        pane.getChildren().add(dot15);
        pane.getChildren().add(dot16);
        pane.getChildren().add(dot17);
        pane.getChildren().add(dot18);        
        pane.getChildren().add(dot19);
        pane.getChildren().add(dot20);
        pane.getChildren().add(dot21);
        pane.getChildren().add(dot22);       
        pane.getChildren().add(dot23);
        pane.getChildren().add(dot24);
        pane.getChildren().add(dot25);
        pane.getChildren().add(dot26);
        pane.getChildren().add(dot27);   
        pane.getChildren().add(dot28);
        
        //Makes a new scene with the title Excercise 7
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Excercise 29");
        primaryStage.setScene(scene);
        //Shows the scene
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }   
}