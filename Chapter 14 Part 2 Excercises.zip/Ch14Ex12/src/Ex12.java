/*
Dylan DeCoster
Chapter 14 Excercise 12
Description: Display a bar chart that shows grades
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.layout.VBox;
import javafx.scene.chart.NumberAxis;

public class Ex12 extends Application{
    @Override    
    public void start(Stage primaryStage){
        //Makes the x axis
        CategoryAxis x = new CategoryAxis();   
        //Makes the y axis
        NumberAxis y = new NumberAxis();
        //Makes the new chart
        BarChart chart = new BarChart(x, y);
        //Makes a thing that can store a series of data
        XYChart.Series main = new XYChart.Series();

        //Adds all the data points
        main.getData().add(new XYChart.Data("Project -- 20%", 20));
        main.getData().add(new XYChart.Data("Quiz -- 10%", 10));
        main.getData().add(new XYChart.Data("Midterm -- 30%", 30));
        main.getData().add(new XYChart.Data("Final -- 40%", 40));
        
        //Gets all the data and adds it to the chart
        chart.getData().add(main);
        //Makes the stuff look better
        VBox vbox = new VBox(chart);
        
        //Makes a new scene that uses the Vbox
        Scene scene = new Scene(vbox);
        
        primaryStage.setTitle("Excercise 12");
        primaryStage.setHeight(500);
        primaryStage.setWidth(500);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    public static void main(String[] args) {
        Application.launch(args);
    }    
}
