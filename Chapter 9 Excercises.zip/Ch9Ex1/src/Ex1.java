/*
Dylan DeCoster
Chapter 9 Excercise 1
Description: Design a class to represent a rectangle.
 */

public class Ex1 {
    public static void main(String[] args){
        //Makes a new rectangle with the following size
        Rectangle rectangle = new Rectangle(4, 40);
        //Prints the rectangles width, height, area, and perimeter
        System.out.println("The width of the rectangle is " + rectangle.width + " and the height of the rectangle is " + rectangle.height +  
                "\nThe area of the rectangle is " + rectangle.getArea() + 
                "\nThe perimeter of the rectangle is " + rectangle.getPerimeter());
        
        //Makes a new line
        System.out.println();
        
        //Makes a new rectangle with the following size
        Rectangle rectangle2 = new Rectangle(3.5, 35.9);
        //Prints the same stuff as the last rectangle for the new one
        System.out.println("The width of the rectangle is " + rectangle2.width + " and the height of the rectangle is " + rectangle2.height +  
                "\nThe area of the rectangle is " + rectangle2.getArea() + 
                "\nThe perimeter of the rectangle is " + rectangle2.getPerimeter());
    }
}
