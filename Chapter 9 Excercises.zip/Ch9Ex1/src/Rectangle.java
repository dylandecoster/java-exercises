class Rectangle{
    //Sets the default size of the rectangle to 1 by 1
    double width = 1, height = 1;
    
    //Sets the variable equal to whatever you input
    public Rectangle(double w, double h){
        width = w;
        height = h;
    }
    
    //Returns the area of the rectangle
    public double getArea(){
        return width * height;
    }
    
    //Returns the perimeter of the rectangle
    public double getPerimeter(){
        return 2 * (width + height);
    }
}