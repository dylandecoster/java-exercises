/*
Dylan DeCoster
Chapter 9 Excercise 8
Description: Makes a fan class that represents a fan
 */

public class ex8 {
    public static void main(String[] args) {
        //Makes a new fan with the following speed, radius, color, and if it is on or off
        Fan fan = new Fan(3, 10.0, "yellow", true);
        //Prints out the fan description
        System.out.println(fan.toString());
        
        //Makes another fan with the following description
        Fan fan2 = new Fan(2, 5.0, "blue", false);
        //Prints the second fans description
        System.out.println(fan2.toString());
    }
}
