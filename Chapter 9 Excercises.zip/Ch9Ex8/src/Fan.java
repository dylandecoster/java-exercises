public class Fan {
    private final int SLOW = 1, MEDIUM = 2, FAST = 2;
    private int speed = SLOW;
    private boolean on = false;
    private double radius = 5;
    private String color = "blue";
    
    //Gets all the info and sets them accordingly
    public Fan(int s, double r, String c, boolean o){
        speed = s;
        radius = r;
        color = c;
        on = o;
    }
    
    //Returns the correct sentence depending on if the fan is on or off
    public String toString(){
        if(on == true)
            return "A " + radius + " inch " + color + " fan at a speed of " + speed;
        else
            return "A " + radius + " inch " + color + " fan; fan is off";
    }   
}
