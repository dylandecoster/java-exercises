/*
Dylan DeCoster
Chapter 9 Excercise 7
Description: 
 */

public class ex7 {
    public static void main(String[] args) {
        //Creates a new account with the folowing stuff in order from id, balance, and interest rate
        Account account = new Account(1122, 20000, 4.5);
        //Withdraws and deposits the money
        Account.withdraw();
        Account.deposit();
        //Prints out the balance and the monthly interest rate
        System.out.println("Your balance is " + Account.balance + " and the monthly interest rate is " + Account.getMonthlyInterest());
    }
}
