/*
Dylan DeCoster
Chapter 9 Excercise 3
Description: Write a program that sets elapsed times to stuff
 */

public class ex3 {
    //Makes the string time which stores the number
    public static String time = "";
    
    public static void main(String[] args) {
        //Makes a new date
        Date date = new Date("10000");
        
        //Adds a 0 every time the date is printied
        for(int i = 0; i < 8; i++, time += "0"){
            //Prints the date using what is returned from the toString() method
            System.out.println(date.toString());
        }
    }
}
