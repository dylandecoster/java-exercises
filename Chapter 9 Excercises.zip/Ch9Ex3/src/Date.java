public class Date {
    public Date(String t){
        //Gets the input from ex3
        ex3.time = t;
    }
    
    public String toString(){
        //Returns the number
        return ex3.time;
    }
}
