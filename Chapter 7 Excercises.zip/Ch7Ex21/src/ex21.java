/*
Project: Chapter 7 Excercise 21
Name: Dylan DeCoster
Date: 9/17/19
Description: Make each ball fall into a random slot
 */

import java.util.Scanner;

public class ex21 {
    public static void main(String[] args) {
       Scanner input = new Scanner(System.in);
       
       //Says all the user input crap
       System.out.print("Enter the number of balls to drop: ");
       int balls = input.nextInt();
       System.out.print("Enter the number of slots in the bean machine: ");
       int slots = input.nextInt();
       
       int[] total = new int[slots + 1];
       int direction;
       //Gets the middle slot where the ball falls from
       int startPos = total.length / 2;
       int currentPos = startPos;
       //Gets all the direction history
       String history = "";
       
       for(int i = 1; i < balls; i++){
           for(int j = 0; j <= slots; j++){
               //Moves either left or right
               direction = (int)(2 * Math.random());
               if(direction == 0){
                    history += "L";
                    //Moves the ball left
                    currentPos = currentPos - 1;
               }
               else{
                    history += "R";
                    //Moves the ball right
                    currentPos = currentPos + 1;
               }
               
               //Makes a new line and resets startPos
               if(history.length() % slots == 0){
                    history += "\n";
                    currentPos = startPos;
               }
           }
           total[i] = currentPos;
       }
       
       //Prints the direction history
       System.out.println(history.substring(1));

       //Kind of prints the slots where the balls drop
       for(int k = 0; k < balls; k++){
            for(int h = 1; h <= total[k]; h++){
                System.out.print(" ");
            }
            System.out.println("0");  
       }
    }
}