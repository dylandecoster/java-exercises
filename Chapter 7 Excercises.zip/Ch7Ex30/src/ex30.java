/*
Project: Chapter 7 Excercise 30
Name: Dylan DeCoster
Date: 9/17/19
Description: The program tests if the array has four consecutive numbers
 */

import java.util.Scanner;

public class ex30 {
    public static void main(String[] args) {
        //Makes a new scanner
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter the number of values: ");
        //Gets the total amount of numbers
        int numCount = input.nextInt();
        System.out.print("Enter the values: ");
        //Sets the array values to the number of numbers in the array
        int[] values = new int[numCount];
        
        //Gets all the values
        for(int i = 0; i < numCount; i++){
            values[i] = input.nextInt();
        }
        
        //Prints the following if the value is true and else prints the other thing
        if(isConsecutiveFour(values) == true)
            System.out.println("The list has consecutive fours");
        else
            System.out.println("The list has no consecutive fours");
    }
    
    public static boolean isConsecutiveFour(int[] values){
        //gets the first value
        int start = values[0];
        int count = 1;
        
        //Checks for the consecutive numbers and adds to count
        for(int i = 0; i < values.length; i++){
            if(start != values[i]){
                start = values[i];
                count = 1;
            }
            else{
                count++;
            }           
        }
        
        //Returns if the count is greater than 4
        if(count >= 4){
            return true;   
        }
        else{
            return false;
        }
    }
}
