/*
Dylan DeCoster
Chapter 15 Exercise 1
Display four cards randomly
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class ex1 extends Application {
    @Override
    public void start(Stage primaryStage) {
        Button btn = new Button();
        btn.setText("Refresh");

        // Creates a new pane and adds padding to it
        GridPane pane = new GridPane();
        pane.setPadding(new Insets(5, 5, 5, 5));
        pane.setHgap(5);
        pane.setVgap(5);

        // Creates the default image views
        ImageView view1 = new ImageView("card/1.png");
        ImageView view2 = new ImageView("card/1.png");
        ImageView view3 = new ImageView("card/1.png");
        ImageView view4 = new ImageView("card/1.png");
        
        // Adds all the images to the scene
        pane.add(view1, 0, 0);
        pane.add(view2, 1, 0);
        pane.add(view3, 2, 0);
        pane.add(view4, 3, 0);
        pane.add(btn, 1, 1);
        
        btn.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                int[] cards = new int[4]; // Holds 4 random numbers
                // Puts the random numbers into the array
                for(int i = 0; i < 4; i++) {
                    cards[i] = (int)(Math.random() * 42 + 1);
                }
                
                // Sets the images to the random images from the array
                Image img1 = new Image("card/" + cards[0] + ".png");
                Image img2 = new Image("card/" + cards[1] + ".png");
                Image img3 = new Image("card/" + cards[2] + ".png");
                Image img4 = new Image("card/" + cards[3] + ".png");

                // Sets the image views to the images
                view1.setImage(img1);
                view2.setImage(img2);
                view3.setImage(img3);
                view4.setImage(img4);            
            }
        });
        
        Scene scene = new Scene(pane);
        primaryStage.setTitle("Exercise 15.1");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
