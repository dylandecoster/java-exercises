/*
Dylan DeCoster
Chapter 15 Exercise 4
Create a simple calculator
 */

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class ex4 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        // Formats and creates the grid pane
        GridPane pane = new GridPane();
        pane.setAlignment(Pos.CENTER);
        pane.setVgap(10);
        pane.setHgap(10);
        
        // Creates and formats all the buttons
        Button add = new Button("Add");
        add.setMinSize(70, 5);
        Button sub = new Button("Subtract");
        sub.setMinSize(70, 5);
        Button multiply = new Button("Multiply");
        multiply.setMinSize(70, 5);
        Button divide = new Button("Divide");
        divide.setMinSize(70, 5);
        
        // Creates and formats all the labels and text fields
        Label label1 = new Label("Number 1: ");
        TextField field1 = new TextField();
        field1.setMaxWidth(70);
        Label label2 = new Label("Number 2: ");
        TextField field2 = new TextField();
        field2.setMaxWidth(70);
        Label label3 = new Label("Result: ");
        TextField field3 = new TextField();
        field3.setMaxWidth(50);
        field3.setEditable(false);
        
        
        
        // Does all the math
        add.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double num1 = Double.parseDouble(field1.getText());
                double num2 = Double.parseDouble(field2.getText());
                field3.setText(Double.toString(num1 + num2));
            }
        });
        sub.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double num1 = Double.parseDouble(field1.getText());
                double num2 = Double.parseDouble(field2.getText());
                field3.setText(Double.toString(num1 - num2));
            }
        });
        multiply.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double num1 = Double.parseDouble(field1.getText());
                double num2 = Double.parseDouble(field2.getText());
                field3.setText(Double.toString(num1 * num2));
            }
        });
        divide.setOnAction(new EventHandler<ActionEvent>() {
            
            @Override
            public void handle(ActionEvent event) {
                double num1 = Double.parseDouble(field1.getText());
                double num2 = Double.parseDouble(field2.getText());
                field3.setText(Double.toString(num1 / num2));
            }
        });

        // Adds everything into the grid pane
        pane.add(add, 0, 1);
        pane.add(sub, 1, 1);
        pane.add(multiply, 2, 1);
        pane.add(divide, 3, 1);
        pane.add(label1, 0, 0);
        pane.add(field1, 1, 0);
        pane.add(label2, 2, 0);
        pane.add(field2, 3, 0);
        pane.add(label3, 4, 0);
        pane.add(field3, 5, 0);

        Scene scene = new Scene(pane, 450, 250);
        
        primaryStage.setTitle("Exercise 15.4");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
