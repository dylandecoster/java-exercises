/*
Dylan DeCoster
Chapter 15 Exercise 28
Create a moving fan
 */

import javafx.animation.*;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ex28 extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        // Creates all the buttons and positions them at the bottom of the screen
        HBox hb = new HBox(5);
        Button pause = new Button("Pause");
        Button resume = new Button("Resume");
        Button reverse = new Button("Reverse");
        hb.setAlignment(Pos.CENTER);
        hb.getChildren().addAll(pause, resume, reverse);
        
        // Creates a new pane for the fan
        BorderPane pane = new BorderPane();
        pane.setBottom(hb);
        
        // Creates the fan
        FanPane fan = new FanPane();
        pane.setCenter(fan);
        
        // Creates the animation
        Timeline animation = new Timeline(
            new KeyFrame(Duration.millis(100), e -> fan.move()));
        animation.setCycleCount(Timeline.INDEFINITE);
        animation.play();
        
        // Sets the buttons to there action
        pause.setOnAction(e -> animation.pause());
        resume.setOnAction(e -> animation.play());
        reverse.setOnAction(e -> fan.reverse());
        
        Scene scene = new Scene(pane, 200, 230);
        
        primaryStage.setTitle("Exercise 15.28");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        // Centers the fan
        scene.widthProperty().addListener(e -> fan.setW(scene.getWidth()));
        scene.heightProperty().addListener(e -> fan.setH(scene.getHeight()));
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
