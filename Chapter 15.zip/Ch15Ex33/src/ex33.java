/*
Dylan DeCoster
Chapter 15 Exercise 33
Create the bean machine
 */

import java.util.Random;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.*;
import javafx.stage.Stage;
import javafx.animation.*;
import javafx.util.Duration;

public class ex33 extends Application {
    Pane pane = new Pane();
    
    double x = 150 , y = 20;
    
    // slots contains the y position and slotsX contains all the centers of the slots
    int[] slots = new int[] {35, 35, 35, 35, 35, 35, 35, 35};
    double[] slotsX = new double[] {62.5, 87.5, 112.5, 137.5, 162.5, 187.5, 212.5, 237.5};
    
    @Override
    public void start(Stage primaryStage) {
        createOutline();
        createPins();

        // Repeats the animation for every ball
        for(int i = 0; i < 10; i++) {
            move();
        }
        
        Scene scene = new Scene(pane, 300, 300);
        
        primaryStage.setTitle("Exercise 15.33");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
    
    // Creates the game board outline
    public void createOutline() {
        Polyline outline = new Polyline(); // Creates a default polyline
        // Creates the shape of the outline
        outline.getPoints().addAll(new Double[] {
            130.0, 25.0,
            130.0, 50.0,
            50.0, 225.0,
            50.0, 270.0,
            250.0, 270.0,
            250.0, 225.0,
            170.0, 50.0,
            170.0, 25.0
        });
        pane.getChildren().add(outline);
        
        // Creates the ball holder parts of the outline
        for(double i = 1; i <= 7; i++) {
            Line line = new Line((i+2) * 25, 270, (i+2) * 25, 225);
            pane.getChildren().add(line);
        }
    }
    
    // Creates all the black pins for the game
    public void createPins() {
        int numPerRow = 7, y = 225;
        double f = 2;
        // Repeats for every row
        for(int i = 1; i <= 7; i++) {
            // Repeats for every ball
            for(int j = 1; j <= numPerRow; j++) {
                Circle circle = new Circle((j+f) * 25, y, 5, Color.BLACK);
                pane.getChildren().add(circle);
            }
            numPerRow--; // Changes the number of balls in the row
            y -= 28; // Moves the new row up
            f += .5; // Does something with the spacing of the balls
        }
    }
    private int n = 0;
    // Moves the ball in a random direction until it ends up at the bottom
    public void move() {
        Random rand = new Random();
        Circle ball = new Circle(400, 400, 4, Color.GRAY);
        Path path = new Path();
        PathTransition anim = new PathTransition(Duration.millis(1000), path, ball);

        path.getElements().add(new MoveTo(x, y)); // Creates the default path location

        for(int j = 0; j < 7; j++) {
            // Chooses a random direction, left or right and moves the ball accordingly
            if (rand.nextInt() % 2 == 0) {
                path.getElements().add(new LineTo(x += 12.5, y += 30));
            } else {
                path.getElements().add(new LineTo(x -= 12.5, y += 30));
            }
        }
        // Puts the ball at the bottom of the slot
        for(int j = 0; j < slotsX.length; j++) {
            if(slotsX[j] == x) { // Checks which slot the ball lands into
                path.getElements().add(new LineTo(x, y += slots[j])); // Sets the ball in the slot
                slots[j] -= 8; // Spaces the balls that are in the same slot
            }
        }
        
        anim.setDelay(Duration.millis(1000 * n++)); // Delays the animations so they don't all run together
        anim.play(); // Plays the animation
        
        x = 150; y =20; // Resets the balls position
        
        pane.getChildren().add(ball);
    }
}
