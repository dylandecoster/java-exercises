/*
Dylan DeCoster
Chapter 15 Exercise 9
Control a line with arrow keys
 */

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Polyline;
import javafx.stage.Stage;

public class ex9 extends Application {
    double currentX = 150, currentY = 150; // Creates a default x and y
    
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        Polyline line = new Polyline(currentX, currentY, 150, 150); // Default polyline
        
        // Adds the line to the scene
        pane.getChildren().add(line);
        // Gets all the key pressed events and extends the line
        line.setOnKeyPressed(e -> {
            switch(e.getCode()) {
                case DOWN: line.getPoints().addAll(currentX, currentY, currentX, currentY + 10); currentY += 10; break;
                case UP: line.getPoints().addAll(currentX, currentY, currentX, currentY - 10); currentY -= 10; break;
                case RIGHT: line.getPoints().addAll(currentX, currentY, currentX + 10, currentY); currentX += 10; break;
                case LEFT: line.getPoints().addAll(currentX, currentY, currentX - 10, currentY); currentX -= 10; break;
        }});
        
        Scene scene = new Scene(pane, 300, 250);
        
        primaryStage.setTitle("Exercise 15.9");
        primaryStage.setScene(scene);
        primaryStage.show();
        
        line.requestFocus(); // Lets the key event thing work
    }

    public static void main(String[] args) {
        launch(args);
    }
    
}
