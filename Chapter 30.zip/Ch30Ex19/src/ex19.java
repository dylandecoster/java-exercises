/*
Dylan DeCoster
Chapter 30 Exercise 19
Create an animation for the selection, insertion, and bubble sort
 */

import java.util.*;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.chart.*;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import javafx.util.Duration;

public class ex19 extends Application {
    GridPane pane = new GridPane(); // Creates an empty grid pane
    
    @Override
    public void start(Stage primaryStage) throws InterruptedException {
        // Creates all the default graphs
        final BarChart<String, Number> selectSort = new BarChart<>(new CategoryAxis(), new NumberAxis());
        final BarChart<String, Number> insertSort = new BarChart<>(new CategoryAxis(), new NumberAxis());
        final BarChart<String, Number> bubbleSort = new BarChart<>(new CategoryAxis(), new NumberAxis());
        // Sets the titles of all the charts
        selectSort.setTitle("Selection Sort");
        insertSort.setTitle("Insertion Sort");
        bubbleSort.setTitle("Bubble Sort");
        // Sets all of the charts values
        createGraph(selectSort, 0);
        createGraph(insertSort, 1);
        createGraph(bubbleSort, 2);
        // Adds all of the charts into the pane
        pane.add(selectSort, 0, 0);
        pane.add(insertSort, 1, 0);
        pane.add(bubbleSort, 2, 0);
        
        Scene scene = new Scene(pane, 800, 300);
        
        primaryStage.setTitle("Exercise 30.19");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public void createGraph(BarChart bc, int type) throws InterruptedException {
        Integer[] arr = new Integer[50]; // Creates a new array with 50 elements
        for(int i = 1; i <= arr.length; i++) // Sets the array to the numbers 1-50 in order
            arr[i-1] = i;
        List<Integer> list = Arrays.asList(arr); // Converts the array to a list
        Collections.shuffle(list); // Shuffles the list
        list.toArray(arr); // Converts the list back to an array
        
        // Adds all the values of the array into the chart
        XYChart.Series<String, Number> selection = new XYChart.Series();
        for(int i = 0; i < arr.length; i++) {
            selection.getData().add(new XYChart.Data(String.valueOf(i), arr[i]));
        }
        bc.getData().addAll(selection);
        
        // Makes the graph look better
        bc.setBarGap(0);
        bc.setCategoryGap(0);
        bc.setMaxWidth(300);
        bc.setMaxHeight(300);
        bc.setLegendVisible(false);
        bc.getYAxis().setOpacity(0);
        bc.getXAxis().setOpacity(0);
        bc.setAnimated(false); // Ensures the bar chart doesn't do some weird crap        
        
        switch(type) {
            case 0: selectSort(arr, selection);
            case 1: insertSort(arr, selection);
            case 2: bubbleSort(arr, selection);
        }
    }
    
    private void selectSort(Integer[] arr, XYChart.Series<String, Number> selection) throws InterruptedException {
        Timeline tl = new Timeline(); // Creates a new timeline
        for(int i = 0; i < arr.length; i++) {
            int min = i; // Stores the current minimum
            //Compares the minimum to every number in the array until it finds a smaller one
            for(int j = i+1; j < arr.length; j++) {
                if(arr[j] < arr[min]) {
                    min = j;
                }
            }
            
            int temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
            
            int tempI = i, tempMin = min; // Stores the current i and minimum
            // Stores the switch of the two numbers as new keyframes
            tl.getKeyFrames().add(new KeyFrame(Duration.millis(i * 100 + 500), (ActionEvent actionEvent) -> {
                selection.getData().set(tempI, new XYChart.Data(String.valueOf(tempI), arr[tempMin])); 
                selection.getData().set(tempI, new XYChart.Data(String.valueOf(tempI), arr[tempI]));
            }));
        }
        tl.play(); // Plays the animation
    }
    
    private void insertSort(Integer[] arr, XYChart.Series<String, Number> selection) {
        Timeline tl = new Timeline(); // Creates a new timeline
        for(int i = 1; i < arr.length; i++) {
            int current = arr[i], j = i-1;
            while(j >= 0 && arr[j] > current) {
                arr[j + 1] = arr[j];
                j -= 1;

                int tempI = i; // Stores the current i and minimum
                tl.getKeyFrames().add(new KeyFrame(Duration.millis(i * 100 + 500), (ActionEvent actionEvent) -> {
                    // Remove the current item
                    selection.getData().remove(tempI);
                    // Add it to the front of the list
                    selection.getData().add(tempI-1, new XYChart.Data(String.valueOf(tempI), arr[tempI]));
                }));
            }
            arr[j + 1] = current;
        }
        tl.play(); // Plays the animation
    }
    
    private void bubbleSort(Integer[] arr, XYChart.Series<String, Number> selection) {
        Timeline tl = new Timeline(); // Creates a new timeline
        int n = arr.length; 
        for(int i = 0; i < n-1; i++) {
            for(int j = 0; j < n-i-1; j++) {
                if(arr[j] > arr[j+1]) {
                    int temp = arr[j];
                    arr[j] = arr[j+1];
                    arr[j+1] = temp;
                    
                    int nextJ = j+1, tempJ = j; // j+1 and j
                    // Stores the switch of the two numbers as new keyframes
                    tl.getKeyFrames().add(new KeyFrame(Duration.millis(i * 100 + 500), (ActionEvent actionEvent) -> {
                        selection.getData().set(nextJ, new XYChart.Data(String.valueOf(nextJ), arr[tempJ])); 
                        selection.getData().set(nextJ, new XYChart.Data(String.valueOf(nextJ), arr[nextJ]));
                    }));
                }
            }
            
        }
        tl.play();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
    
}
