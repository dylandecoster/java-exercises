/*
Dylan DeCoster
Chapter 30 Exercise 15
Implement the parallel sum method using fork/join in a list of 9 million double values
 */

import java.util.concurrent.*;

public class ex15 {
    public static void main(String[] args) {
        double[] list = new double[9000000]; // Creates a new list with a size of 9 million
        for(int i = 0; i < list.length; i++)
            list[i] = (double)(Math.random() * 1000); // Sets every item in the list to a random number
        parallelSum(list); // Calculates the sum
    }
    
    public static void parallelSum(double[] list) {
        RecursiveAction task = new SumTask(list); // Creates a new task
        ForkJoinPool pool = new ForkJoinPool(); // Creates a ForkJoinPool
        pool.invoke(task); // Adds the task to the pool
    }
    
    private static class SumTask extends RecursiveAction {
        double sum = 0; // Creates a new sum defaulted to 0
        private double[] list; // Creates an empty list
        
        // Constructor to get the list
        SumTask(double[] list) {
            this.list = list; // Sets the list
        }
        
        @Override
        public void compute() {
            // Adds the current list item to the sum for every item in the list
            for(int i = 0; i < list.length; i++)
                sum += list[i];
            System.out.println("The total sum is: " + sum); // Prints the total
        }
    }
}
