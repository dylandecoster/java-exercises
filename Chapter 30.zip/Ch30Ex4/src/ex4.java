/*
Dylan DeCoster
Chapter 30 Exercise 4
Create a program that launches 1,000 threads
 */

import java.util.concurrent.*;

public class ex4 {
    private static NoSyncTotal noSyncTotal = new NoSyncTotal();
    private static SyncedTotal syncedTotal = new SyncedTotal();
    
    public static void main(String[] args) {
        ExecutorService executor = Executors.newCachedThreadPool(); // Creates the thread pool

        // Adds to the sum 1000 times
        for(int i = 0; i < 1000; i++) {
            executor.execute(new AddToSum());
        }
        
        executor.shutdown(); // Shuts the executor down after its done
        while(!executor.isTerminated()); // Waits for the executor to be shutdown
        
        System.out.println(syncedTotal.getSum()); // Prints the sum
    }
    
    public static class AddToSum implements Runnable {
        public void run() {
            syncedTotal.add(); // Adds to sum
        }
    }
}