import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

class SyncedTotal {
    private static Lock lock = new ReentrantLock(); // Creates a new lock
    private int sum = 0;
    Integer Sum = new Integer(sum);

    // Returns the current sum
    public int getSum() {
        return Sum;
    }

    public void add() {
        lock.lock();

        try {
            int newSum = Sum + 1; // Creates an int that adds 1 to sum
            Thread.sleep(5);
            Sum = newSum; // Sets sum to the new sum
        }catch (InterruptedException ex) {
        } finally {
            lock.unlock();
        }
    }
}