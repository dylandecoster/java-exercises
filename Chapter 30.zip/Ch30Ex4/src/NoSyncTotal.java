class NoSyncTotal {
    private int sum = 0;
    Integer Sum = new Integer(sum);

    // Returns the current sum
    public int getSum() {
        return Sum;
    }

    public void add() {
        int newSum = Sum + 1; // Creates an int that adds 1 to sum

        // Prevents data corruption
        try {
            Thread.sleep(5);
        } catch (InterruptedException ex) {
        }

        Sum = newSum; // Sets sum to the new sum
    }
}