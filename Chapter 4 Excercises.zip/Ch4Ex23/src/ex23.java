/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex23 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declares a new scanner called input
        Scanner input = new Scanner(System.in);
        
        //Prints all the questions
        System.out.println("Enter employee's name: ");
        System.out.println("Enter number of hours worked in a week: ");
        System.out.println("Enter hourly pay rate: ");
        System.out.println("Enter federal tax withholding rate: ");
        System.out.println("Enter state tax withholding rate: ");
        
        //Gets all the inputs
        String name = input.nextLine();
        float hours = input.nextFloat();
        float pay = input.nextFloat();
        float federal = input.nextFloat();
        float state = input.nextFloat();
        
        //Does all the math
        float grossPay = hours * pay;
        float totalFederal = federal * grossPay;
        float totalState = state * grossPay;
        float totalDeductions = totalFederal + totalState;
        
        //Prints everything out
        System.out.println("Employee Name: " + name);
        System.out.println("Hours Worked: " + hours);
        System.out.println("Pay Rate: $" + pay);
        System.out.println("Gross Pay: $" + (grossPay));
        System.out.println("Deductions: ");
        System.out.printf("    Federal Withholding (20.0%%): $%.2f%n" , totalFederal);
        System.out.printf("    State Withholding (9.0%%): $%.2f%n" , totalState);
        System.out.printf("    Total Deduction: $%.2f%n" , totalDeductions);
        System.out.printf("Net Pay: $%.2f%n" , (grossPay - totalDeductions));
    }
    
}
