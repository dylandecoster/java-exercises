/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Programming
 */
import java.util.Scanner;

public class ex13 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //Declares a new scanner input
        Scanner input = new Scanner(System.in);
        
        //Gets the input
        System.out.print("Enter a letter: ");
        char letter = input.nextLine().charAt(0);
        String answer = "";
        
        //Checks what the letter is
        if(Character.isLetter(letter)){
            switch(letter){
                case 'a':
                case 'A': answer = "vowel"; break;   
                case 'e':
                case 'E': answer = "vowel"; break;   
                case 'i':
                case 'I': answer = "vowel"; break;   
                case 'o':
                case 'O': answer = "vowel"; break;   
                case 'u':
                case 'U': answer = "vowel"; break;   
                default: answer = "consonant"; break;
            }
            
            //Prints the result
            System.out.println(letter + " is a " + answer);
        }
        else{
            System.out.println(letter + " is an invalid input");
        }

    }
    
}
